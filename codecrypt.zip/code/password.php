<?php
session_start();
include 'config.php';

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    echo "<script>
            alert('Unauthorized access. Please log in first.');
            window.location.href='signin.html';
          </script>";
    exit();
}

// Get form data
$old_username = trim($_POST['old_username']);
$old_password = trim($_POST['old_password']);
$new_username = trim($_POST['new_username']);
$new_password = trim($_POST['new_password']);

// Validate inputs
if (
    empty($old_username) ||
    empty($old_password) ||
    empty($new_username) ||
    empty($new_password)
) {
    echo "<script>
            alert('Please fill in all fields.');
            window.location.href='home.php';
          </script>";
    exit();
}

try {

    // Verify old username
    $stmt = $conn->prepare("SELECT password FROM users WHERE username = :username");
    $stmt->execute([
        ':username' => $old_username
    ]);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user || !password_verify($old_password, $user['password'])) {
        echo "<script>
                alert('Invalid username or password.');
                window.location.href='home.php';
              </script>";
        exit();
    }

    // Check if new username already exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = :username");
    $stmt->execute([
        ':username' => $new_username
    ]);

    if ($stmt->fetch()) {
        echo "<script>
                alert('New username already exists.');
                window.location.href='home.php';
              </script>";
        exit();
    }

    // Hash new password
    $hashedPassword = password_hash($new_password, PASSWORD_DEFAULT);

    // Update username and password
    $stmt = $conn->prepare("
        UPDATE users
        SET username = :new_username,
            password = :password
        WHERE username = :old_username
    ");

    $success = $stmt->execute([
        ':new_username' => $new_username,
        ':password' => $hashedPassword,
        ':old_username' => $old_username
    ]);

    if ($success) {

        $_SESSION['username'] = $new_username;

        echo "<script>
                alert('Authentication details updated successfully!');
                window.location.href='home.php';
              </script>";

    } else {

        echo "<script>
                alert('Error updating authentication details.');
                window.location.href='home.php';
              </script>";

    }

} catch (PDOException $e) {

    die("Database Error: " . $e->getMessage());

}
?>