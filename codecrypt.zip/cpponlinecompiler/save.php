<?php
session_start();

// Get user ID from session (default to "guest" if not logged in)
$userid = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : "guest";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $filename = $_POST["filename"];
    $code = $_POST["code"];

    // Sanitize filename to allow only safe characters
    $filename = preg_replace("/[^a-zA-Z0-9_\-\.]/", "", $filename);

    // Ensure filename ends with ".cpp"
    if (!preg_match("/\.cpp$/", $filename)) {
        $filename .= ".cpp";
    }

    // Define the folder based on user ID
    $folder = "../flask_project/saved_files/$userid";

    // Create folder if it doesn't exist
    if (!is_dir($folder)) {
        mkdir($folder, 0777, true);
    }

    // Full path of the file
    $filepath = "$folder/$filename";

    // Save the file
    if (file_put_contents($filepath, $code) !== false) {
        echo json_encode(["status" => "success", "message" => "File saved successfully!", "filepath" => htmlspecialchars($filepath)]);
    } else {
        echo json_encode(["status" => "error", "message" => "Error saving file."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request."]);
}
?>
