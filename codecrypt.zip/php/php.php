<?php
session_start();

header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    echo json_encode(["error" => "Invalid request"]);
    exit;
}

$action = $_POST["action"] ?? "";

if ($action == "run") {

    $code = $_POST["code"] ?? "";

    $payload = [
        "clientId" => "a07f369753f34bc4f305f3f1fcf73bdd",
        "clientSecret" => "2a8d8140422f67031a0c8038fd74643109c7b2263a90766d9272aaeba54fffe4",
        "script" => $code,
        "language" => "php",
        "versionIndex" => "4"
    ];

    $ch = curl_init("https://api.jdoodle.com/v1/execute");

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            "Content-Type: application/json"
        ],
        CURLOPT_POSTFIELDS => json_encode($payload)
    ]);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        echo json_encode([
            "error" => curl_error($ch)
        ]);
        curl_close($ch);
        exit;
    }

    curl_close($ch);

    echo $response;
    exit;
}

if ($action == "save") {

    $userid = $_SESSION['user_id'];

    $saved_dir = "../flask_project/saved_files/$userid";

    if (!file_exists($saved_dir)) {
        mkdir($saved_dir, 0777, true);
    }

    $filename = preg_replace('/[^a-zA-Z0-9-_]/', '', $_POST["filename"]) . ".php";

    $code = $_POST["code"];

    file_put_contents("$saved_dir/$filename", $code);

    echo json_encode([
        "success" => true
    ]);
}