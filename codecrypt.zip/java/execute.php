<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: ../code/signin.html");
    exit();
}

header("Content-Type: application/json");

// Your API endpoint and credentials
$api_url = "https://api.jdoodle.com/v1/execute"; // Replace with your actual API
$client_id = "a07f369753f34bc4f305f3f1fcf73bdd"; // Replace with your actual Client ID
$client_secret = "2a8d8140422f67031a0c8038fd74643109c7b2263a90766d9272aaeba54fffe4"; // Replace with your actual Client Secret

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $code = isset($_POST["code"]) ? $_POST["code"] : "";
    $input = isset($_POST["input"]) ? $_POST["input"] : "";

    if (empty($code)) {
        echo json_encode(["error" => "Code cannot be empty"]);
        exit();
    }

    // Prepare API request payload
    $payload = json_encode([
        "clientId" => $client_id,
        "clientSecret" => $client_secret,
        "script" => $code,
        "stdin" => $input, // Standard input for Java program
        "language" => "java",
        "versionIndex" => "4" // Java 11, change if needed
    ]);

    // Initialize cURL
    $ch = curl_init($api_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);

    // Execute API request
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($http_code != 200) {
        echo json_encode(["error" => "API request failed", "details" => $response]);
        exit();
    }

    // Return API response
    echo $response;
}
?>
