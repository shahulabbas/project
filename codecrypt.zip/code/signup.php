<?php
session_start();
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    try {

        $firstName = trim($_POST['firstName']);
        $lastName  = trim($_POST['lastName']);
        $mobile    = trim($_POST['mobile']);
        $username  = trim($_POST['username']);
        $password  = password_hash($_POST['password'], PASSWORD_DEFAULT);

        // Validate required fields
        if (empty($firstName) || empty($lastName) || empty($mobile) || empty($username) || empty($_POST['password'])) {
            die("Please fill all fields.");
        }

        // Check if username already exists
        $check = $conn->prepare("SELECT id FROM users WHERE username = :username");
        $check->execute([
            ':username' => $username
        ]);

        if ($check->fetch()) {
            die("Username already exists.");
        }

        // Default profile picture
        $profilePath = "profile/default.png";

        // Upload profile picture (optional)
        if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] != UPLOAD_ERR_NO_FILE) {

            if ($_FILES['profile_pic']['error'] != UPLOAD_ERR_OK) {
                die("Upload Error Code: " . $_FILES['profile_pic']['error']);
            }

            if (!file_exists("profile")) {
                mkdir("profile", 0777, true);
            }

            $fileName = $_FILES['profile_pic']['name'];
            $tmpName  = $_FILES['profile_pic']['tmp_name'];

            $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'jfif'];

            if (!in_array($ext, $allowed)) {
                die("Invalid image format. Allowed: jpg, jpeg, png, gif, webp, jfif");
            }

            $newFileName = uniqid() . "." . $ext;
            $profilePath = "profile/" . $newFileName;

            if (!move_uploaded_file($tmpName, $profilePath)) {
                die("Failed to upload image.");
            }
        }

        // Insert user
        $stmt = $conn->prepare("
            INSERT INTO users
            (
                first_name,
                last_name,
                mobile,
                username,
                password,
                profile_pic
            )
            VALUES
            (
                :fname,
                :lname,
                :mobile,
                :username,
                :password,
                :pic
            )
        ");

        $stmt->execute([
            ':fname'    => $firstName,
            ':lname'    => $lastName,
            ':mobile'   => $mobile,
            ':username' => $username,
            ':password' => $password,
            ':pic'      => $profilePath
        ]);

        echo "<script>
            alert('Registration Successful');
            window.location='signin.html';
        </script>";

    } catch (PDOException $e) {
        die("Database Error: " . $e->getMessage());
    }

}
?>