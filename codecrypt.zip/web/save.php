<?php
session_start();

// Custom directory path based on user ID
$userid = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : "guest";
$saved_dir = "../flask_project/saved_files/$userid";

// Ensure the directory exists
if (!file_exists($saved_dir)) {
    mkdir($saved_dir, 0777, true);
}

// Get POST data
$filename = isset($_POST["filename"]) ? preg_replace('/[^a-zA-Z0-9-_]/', '', $_POST["filename"]) : "index";
$html = isset($_POST["html"]) ? $_POST["html"] : "";
$css = isset($_POST["css"]) ? $_POST["css"] : "";
$js = isset($_POST["js"]) ? $_POST["js"] : "";

// Create a full HTML file
$fileContent = "<!DOCTYPE html>\n<html>\n<head>\n<style>\n$css\n</style>\n</head>\n<body>\n$html\n<script>\n$js\n</script>\n</body>\n</html>";

// Save the file
$file = "$saved_dir/$filename.html";
if (file_put_contents($file, $fileContent) !== false) {
    echo json_encode(["success" => true, "filepath" => $file]);
} else {
    echo json_encode(["success" => false]);
}
?>
