<?php
session_start();
include 'config.php';

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    echo "<script>
            alert('Unauthorized access. Please log in first.');
            window.location.href='signin.html';
          </script>";
    exit();
}

$first_name = trim($_POST['first_name']);
$last_name = trim($_POST['last_name']);
$newProfilePic = "";

// Validate input
if (empty($first_name) || empty($last_name)) {
    echo "<script>
            alert('Please fill in all fields.');
            window.location.href='home.php';
          </script>";
    exit();
}

try {

    // Get existing profile picture
    $stmt = $conn->prepare("SELECT profile_pic FROM users WHERE username = :username");
    $stmt->execute([
        ':username' => $_SESSION['username']
    ]);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    $existingProfilePic = $user ? $user['profile_pic'] : "profile/default.png";

    // Keep old picture if no new one is uploaded
    $newProfilePic = $existingProfilePic;

    // Upload new profile picture
    if (!empty($_FILES["profile_pic"]["name"])) {

        $target_dir = "profile/";

        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $file_name = basename($_FILES["profile_pic"]["name"]);
        $imageFileType = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        $valid_extensions = ["jpg","jpeg","png","gif"];

        if (!in_array($imageFileType, $valid_extensions)) {

            echo "<script>
                    alert('Only JPG, JPEG, PNG and GIF files are allowed.');
                    window.location.href='home.php';
                  </script>";
            exit();
        }

        $newProfilePic = $target_dir . $_SESSION['username'] . "." . $imageFileType;

        // Delete old picture
        if (
            !empty($existingProfilePic) &&
            file_exists($existingProfilePic) &&
            $existingProfilePic != "profile/default.png"
        ) {
            unlink($existingProfilePic);
        }

        if (!move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $newProfilePic)) {

            echo "<script>
                    alert('Error uploading profile picture.');
                    window.location.href='home.php';
                  </script>";
            exit();
        }
    }

    // Update database
    $stmt = $conn->prepare("
        UPDATE users
        SET
            first_name = :first_name,
            last_name = :last_name,
            profile_pic = :profile_pic
        WHERE username = :username
    ");

    $success = $stmt->execute([
        ':first_name' => $first_name,
        ':last_name' => $last_name,
        ':profile_pic' => $newProfilePic,
        ':username' => $_SESSION['username']
    ]);

    if ($success) {

        $_SESSION['first_name'] = $first_name;
        $_SESSION['last_name'] = $last_name;
        $_SESSION['profile_pic'] = $newProfilePic;

        echo "<script>
                alert('Profile updated successfully!');
                window.location.href='home.php';
              </script>";

    } else {

        echo "<script>
                alert('Error updating profile.');
                window.location.href='home.php';
              </script>";

    }

} catch (PDOException $e) {

    die("Database Error: " . $e->getMessage());

}
?>