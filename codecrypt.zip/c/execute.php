<?php
$clientId = "a07f369753f34bc4f305f3f1fcf73bdd";  // Replace with your JDoodle Client ID
$clientSecret = "2a8d8140422f67031a0c8038fd74643109c7b2263a90766d9272aaeba54fffe4";  // Replace with your JDoodle Secret

header("Content-Type: application/json");

// Read request data
$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['code'])) {
    echo json_encode(["output" => "No code received."]);
    exit;
}

$code = $data['code'];
$input = isset($data['stdin']) ? $data['stdin'] : "";

// JDoodle API payload
$payload = [
    "script" => $code,
    "language" => "c",
    "versionIndex" => "5",
    "stdin" => $input,
    "clientId" => $clientId,
    "clientSecret" => $clientSecret
];

$ch = curl_init("https://api.jdoodle.com/v1/execute");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

// Check for cURL errors
if ($curlError) {
    echo json_encode(["output" => "cURL Error: $curlError"]);
    exit;
}

// Check for valid JSON response
$jsonResponse = json_decode($response, true);
if ($jsonResponse === null && json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode(["output" => "Invalid JSON response from JDoodle."]);
    exit;
}

// Return output
echo $response;
?>
