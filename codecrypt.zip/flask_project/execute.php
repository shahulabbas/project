<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);

if ($data === null) {
    echo json_encode(["error" => "Invalid JSON"]);
    exit;
}

$code = $data['code'] ?? "";
$stdin = $data['stdin'] ?? "";

$payload = [
    "script" => $code,
    "language" => "python3",
    "versionIndex" => "3",
    "stdin" => $stdin,
    "clientId" => "a07f369753f34bc4f305f3f1fcf73bdd",
    "clientSecret" => "2a8d8140422f67031a0c8038fd74643109c7b2263a90766d9272aaeba54fffe4"
];

$options = [
    "http" => [
        "method" => "POST",
        "header" => "Content-Type: application/json\r\n",
        "content" => json_encode($payload),
        "ignore_errors" => true
    ]
];

$context = stream_context_create($options);

$response = file_get_contents(
    "https://api.jdoodle.com/v1/execute",
    false,
    $context
);

if ($response === false) {
    echo json_encode([
        "error" => "API request failed",
        "details" => error_get_last()
    ]);
    exit;
}

echo $response;
exit;
?>