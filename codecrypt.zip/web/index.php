<?php
session_start();
if (!isset($_SESSION['username'])) { header("Location: ../code/signin.html"); exit(); }
$user = $_SESSION['username'];
$firstname = isset($_SESSION['first_name']) && isset($_SESSION['last_name']) ? $_SESSION['first_name'].' '.$_SESSION['last_name'] : "User";
$profilePic = isset($_SESSION['profile_pic']) ? $_SESSION['profile_pic'] : "profile/default.png";
$userid = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Online Web Editor | Code Crypt</title>
          <link rel="icon" type="image/x-icon" href="../images/logo.jpeg">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.5/codemirror.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.5/theme/dracula.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.5/codemirror.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.5/mode/xml/xml.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.5/mode/css/css.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.5/mode/javascript/javascript.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.5/mode/htmlmixed/htmlmixed.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.5/addon/edit/matchbrackets.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.5/addon/edit/closebrackets.min.js"></script>
<style>
:root{
  --bg-0:#070a13;--bg-1:#0d1220;--bg-2:#131a2c;--surface:#171f34;--surface-2:#1e2743;
  --border:rgba(148,163,184,.14);--border-strong:rgba(148,163,184,.28);
  --text:#e8edf7;--muted:#8b95b0;
  --html-1:#E44D26;--html-2:#F16529;--html-glow:rgba(228,77,38,.35);
  --grad-html:linear-gradient(135deg,#E44D26 0%,#F16529 100%);
}
*{margin:0;padding:0;box-sizing:border-box}
html,body{background:var(--bg-0);color:var(--text);font-family:'Inter',sans-serif;min-height:100vh}
body{background:
  radial-gradient(1000px 500px at 10% -10%,rgba(228,77,38,.15),transparent 60%),
  radial-gradient(900px 500px at 110% 10%,rgba(241,101,41,.12),transparent 60%),
  var(--bg-0);}
.header-1{
    display:flex;justify-content:space-between;align-items:center;
    padding:20px 40px;
  }
  .logo-section{display:flex;align-items:center;gap:14px}
  .logo-box{
    width:56px;height:56px;border-radius:16px;background:var(--grad);
    display:flex;align-items:center;justify-content:center;box-shadow:var(--shadow);
    overflow:hidden;
  }
  .logo-box img{width:100%;height:100%;object-fit:cover}
  .logo-section h2{font-size:18px;font-weight:800;letter-spacing:1px;line-height:1.2}
  .logo-section h2 span{display:block;font-size:12px;font-weight:400;color:var(--muted);letter-spacing:.3px}
  .profile-section{
    display:flex;align-items:center;gap:12px;padding:8px 16px 8px 8px;border-radius:999px;
    background:var(--panel);border:1px solid var(--border);cursor:pointer;transition:.2s;
  }
  .profile-section:hover{background:var(--panel-2);border-color:var(--border-strong)}
  .profile-section img{width:40px;height:40px;border-radius:50%;object-fit:cover}
  .profile-section h2{font-size:14px;font-weight:600}
  .profile-section .status{font-size:11px;color:green;display:flex;align-items:center;gap:4px}
  .profile-section .status::before{content:"";width:6px;height:6px;background:green;border-radius:50%}

.main-section{
    display:grid;grid-template-columns:1fr;gap:24px;
    padding:0 40px;max-width:1400px;margin:0 auto;
  }

  /* Hero row: title + languages */
  .hero-card{
   /* background:linear-gradient(180deg,rgba(28,28,61,.6),rgba(22,22,50,.6));*/
    border:1px solid var(--border);border-radius:24px;
    display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:24px;
  }
  .hero-left .chip{
    display:inline-block;padding:6px 14px;border-radius:999px;
    background:var(--grad-soft);border:1px solid rgba(99,102,241,.3);
    color:#a5b4fc;font-size:12px;font-weight:600;margin-bottom:14px;
  }
  .hero-left h1{font-size:32px;font-weight:800;letter-spacing:-.5px}
  .hero-left h1 span{background:var(--grad);-webkit-background-clip:text;background-clip:text;color:transparent}
  .hero-left p{color:var(--muted);margin-top:6px;font-size:14px}

  /* Language picker */
  .lang-sec{display:flex;gap:12px;flex-wrap:wrap;justify-content:space-between;align-items:center;padding:0}
  .lang-sec .lang{
    width:76px;height:76px;border-radius:16px;background:var(--panel);
    border:1px solid var(--border);display:flex;flex-direction:column;align-items:center;justify-content:center;
    gap:4px;cursor:pointer;transition:.25s;position:relative;
  }
  .lang-sec .lang:hover{transform:translateY(-3px);border-color:rgba(139,92,246,.5)}
  .lang-sec .lang img{width:34px;height:34px;object-fit:contain}
  .lang-sec .lang small{font-size:10px;color:var(--muted);font-weight:500}
  .lang-sec .lang.active{background:var(--grad);border-color:transparent;box-shadow:var(--shadow)}
  .lang-sec .lang.active small{color:#fff}

.editor-container.platform{background:linear-gradient(180deg,var(--bg-1),var(--bg-2));
  border:1px solid var(--border);border-radius:22px;padding:22px;display:flex;flex-direction:column;gap:20px;min-height:calc(100vh - 140px)}
.language{display:flex;align-items:center;justify-content:space-between;gap:16px;
  padding:18px 22px;border-radius:18px;
  position:relative;overflow:hidden}
.language::before{content:"";position:absolute;;
  background:radial-gradient(500px 200px at 90% 50%,rgba(255,255,255,.18),transparent 60%)}
.language h2{color:#fff !important;font-size:24px;font-weight:800;z-index:1;display:flex;align-items:center;gap:10px}
.language>img{width:56px;height:56px;border-radius:50%;border:3px solid rgba(255,255,255,.4);z-index:1;background:#fff}
.buttons{display:flex;gap:10px;z-index:1}
.buttons button{padding:10px 18px;border:none;border-radius:10px;font-weight:600;cursor:pointer;
  font-family:inherit;font-size:14px;display:inline-flex;align-items:center;gap:8px;transition:.2s;
  background:rgba(255,255,255,.15);color:#fff;backdrop-filter:blur(8px);border:1px solid rgba(255,255,255,.25)}
.buttons button:hover{background:rgba(255,255,255,.28);transform:translateY(-1px)}

.langs{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}
.editor{background:var(--bg-0);border:1px solid var(--border);border-radius:14px;overflow:hidden;display:flex;flex-direction:column}
.editor h3{padding:12px 16px;font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:1px;
  background:var(--surface);border-bottom:1px solid var(--border);display:flex;align-items:center;gap:8px}
.editor:nth-child(1) h3{color:#E44D26}
.editor:nth-child(2) h3{color:#2965F1}
.editor:nth-child(3) h3{color:#F7DF1E}
.editor .CodeMirror{height:280px !important;font-family:'JetBrains Mono',monospace !important;font-size:13px}

.preview-wrap{background:var(--surface);border:1px solid var(--border);border-radius:16px;overflow:hidden}
.preview-wrap h2{padding:14px 18px;font-size:15px;font-weight:700;text-transform:uppercase;letter-spacing:1px;
  color:var(--muted);background:var(--surface-2);border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px}
.preview-wrap h2 i{color:var(--html-1)}
#preview{width:100%;height:420px;border:none;background:#fff}

/* popup */
.popup{display:none;position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);
  background:var(--surface);border:1px solid var(--border-strong);border-radius:18px;
  padding:26px;min-width:340px;z-index:100;box-shadow:0 20px 60px rgba(0,0,0,.6)}
.popup h3{margin-bottom:14px;font-size:18px;font-weight:700;color:var(--html-1);display:flex;align-items:center;gap:10px}
.popup label{display:block;font-size:13px;color:var(--muted);margin-bottom:6px}
.popup input{width:100%;padding:10px 14px;background:var(--bg-0);border:1px solid var(--border);
  border-radius:10px;color:var(--text);font-family:inherit;font-size:14px;margin-bottom:16px;outline:none}
.popup input:focus{border-color:var(--html-1);box-shadow:0 0 0 3px var(--html-glow)}
.popup button{padding:10px 18px;border:none;border-radius:10px;font-weight:600;cursor:pointer;
  font-family:inherit;font-size:14px;margin-right:8px;transition:.2s}
.popup button:first-of-type{background:var(--grad-html);color:#fff}
.popup button:last-of-type{background:var(--bg-2);color:var(--muted);border:1px solid var(--border)}
.popup button:hover{transform:translateY(-1px)}
.popup-backdrop{display:none;position:fixed;inset:0;background:rgba(0,0,0,.6);backdrop-filter:blur(6px);z-index:99}

@media (max-width:900px){
  .main-section{grid-template-columns:1fr}
  .lang-sec{flex-direction:row;overflow-x:auto;position:static}
  .langs{grid-template-columns:1fr}
  .language{flex-wrap:wrap}
}
</style>
</head>
<body>
<header class="header-1">
  <div class="logo-section">
    <div class="logo-box"><img src="../images/logo.jpeg" alt="Logo"></div>
    <h2>CODE CRYPT<span>Developer's Option</span></h2>
  </div>
  <div class="profile-section" onclick="togglePopup && togglePopup()">
    <img src="../code/<?php echo $profilePic; ?>" alt="">
    <div>
      <h2><?php echo $firstname; ?></h2>
      <div class="status">Online</div>
    </div>
  </div>
</header>


<main class="main-section">

  <section class="lang-sec">
    <div class="hero-left">
      <span class="chip">Welcome back</span>
      <h1>Hey, <span><?php echo $firstname; ?></span> 👋</h1>
      <p>Write, run and save code across languages — right in your browser.</p>
    </div>
    <div class="lang-sec">
      <div class="lang" onclick="python()"><img src="../images/python.png"><small>Python</small></div>
      <div class="lang" onclick="java()"><img src="../images/java.png"><small>Java</small></div>
      <div class="lang" onclick="php()"><img src="../images/php.png"><small>PHP</small></div>
      <div class="lang active" style="background:linear-gradient(135deg,#6366f1 0%,#8b5cf6 100%)" onclick="html()"><img src="../images/html.png"><small>HTML</small></div>
      <div class="lang" onclick="js()"><img src="../images/js.png"><small>JS</small></div>
      <div class="lang" onclick="c()"><img src="../images/c.png"><small>C</small></div>
      <div class="lang" onclick="cpp()"><img src="../images/cpp.png"><small>C++</small></div>
    </div></section>

  <div class="editor-container platform">
    <div class="language">
      <h2><i class="fa-brands fa-html5"></i> Web Development</h2>
      <div class="buttons">
        <button onclick="openSavePopup()" style="background:linear-gradient(135deg,#6366f1 0%,#8b5cf6 100%)"><i class="fa-solid fa-floppy-disk"></i> Save</button>
        <button onclick="goHome()"><i class="fa-solid fa-house"></i> Home</button>
      </div>
    </div>

    <div class="langs">
      <div class="editor">
        <h3><i class="fa-brands fa-html5"></i> HTML</h3>
        <textarea id="htmlCode"><h1>Hello, World!</h1>
<p>Start building with Code Crypt.</p></textarea>
      </div>
      <div class="editor">
        <h3><i class="fa-brands fa-css3-alt"></i> CSS</h3>
        <textarea id="cssCode">body{font-family:sans-serif;background:#f7f7fb;color:#111;padding:24px}
h1{color:#E44D26}</textarea>
      </div>
      <div class="editor">
        <h3><i class="fa-brands fa-js"></i> JavaScript</h3>
        <textarea id="jsCode">console.log("Preview ready");</textarea>
      </div>
    </div>

    <div class="preview-wrap">
      <h2><i class="fa-solid fa-eye"></i> Live Preview</h2>
      <iframe id="preview"></iframe>
    </div>
  </div>

  <div class="popup-backdrop" id="popupBackdrop" onclick="closeSavePopup()"></div>
  <div id="savePopup" class="popup">
    <h3><i class="fa-solid fa-floppy-disk"></i> Save HTML File</h3>
    <label for="filename">Enter File Name</label>
    <input type="text" id="filename" placeholder="mypage" required>
    <div>
      <button onclick="saveFile()"><i class="fa-solid fa-check"></i> Save</button>
      <button onclick="closeSavePopup()">Cancel</button>
    </div>
  </div>
</section>

<script>
var htmlEditor = CodeMirror.fromTextArea(document.getElementById("htmlCode"),{
  mode:"htmlmixed",theme:"dracula",lineNumbers:true,indentUnit:2,matchBrackets:true,autoCloseBrackets:true,lineWrapping:true});
var cssEditor = CodeMirror.fromTextArea(document.getElementById("cssCode"),{
  mode:"css",theme:"dracula",lineNumbers:true,indentUnit:2,matchBrackets:true,autoCloseBrackets:true,lineWrapping:true});
var jsEditor = CodeMirror.fromTextArea(document.getElementById("jsCode"),{
  mode:"javascript",theme:"dracula",lineNumbers:true,indentUnit:2,matchBrackets:true,autoCloseBrackets:true,lineWrapping:true});

function updatePreview(){
  const html = htmlEditor.getValue();
  const css = "<style>"+cssEditor.getValue()+"</style>";
  const js = "<script>"+jsEditor.getValue()+"<\/script>";
  const frame = document.getElementById("preview");
  const doc = frame.contentDocument || frame.contentWindow.document;
  doc.open(); doc.write(html+css+js); doc.close();
}
htmlEditor.on("change",updatePreview);
cssEditor.on("change",updatePreview);
jsEditor.on("change",updatePreview);
setTimeout(updatePreview,150);

function openSavePopup(){
  document.getElementById("savePopup").style.display="block";
  document.getElementById("popupBackdrop").style.display="block";
}
function closeSavePopup(){
  document.getElementById("savePopup").style.display="none";
  document.getElementById("popupBackdrop").style.display="none";
}

function saveFile(){
  const html = htmlEditor.getValue();
  const css = cssEditor.getValue();
  const js = jsEditor.getValue();
  const filename = document.getElementById("filename").value.trim();
  if(!filename){ alert("Please enter a valid filename."); return; }
  fetch("save.php",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},
    body:"filename="+encodeURIComponent(filename)+"&html="+encodeURIComponent(html)+
         "&css="+encodeURIComponent(css)+"&js="+encodeURIComponent(js)})
    .then(r=>r.json()).then(d=>{
      if(d.success){ alert("File saved: "+d.filepath); closeSavePopup(); }
      else alert("Error saving file.");
    }).catch(e=>console.error(e));
}

function python(){location.href='../flask_project/index.php'}
function java(){location.href='../java/java.php'}
function php(){location.href='../php/index.php'}
function js(){location.href='../jsonlinecompiler/index.php'}
function html(){location.href='../web/index.php'}
function c(){location.href='../c/index.php'}
function cpp(){location.href='../cpponlinecompiler/index.php'}
function goHome(){location.href='../code/home.php'}
</script>
</body>
</html>
