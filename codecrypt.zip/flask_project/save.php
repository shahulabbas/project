<?php
session_start();
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

// Check if the user is authenticated
if (!isset($_SESSION['user_id'])) {
    echo json_encode(["success" => false, "error" => "User not authenticated"]);
    exit();
}

$username = $_SESSION['user_id'];
$filename = isset($_POST['filename']) ? preg_replace('/[^a-zA-Z0-9-_]/', '', $_POST['filename']) : 'untitled';
$code = isset($_POST['code']) ? $_POST['code'] : '';

// Ensure user-specific directory exists
$user_folder = "saved_files/$username";
if (!is_dir($user_folder)) {
    mkdir($user_folder, 0777, true);
}

// Define file path
$file_path = "$user_folder/$filename.py";

// Save file and return response
if (file_put_contents($file_path, $code) !== false) {
    echo json_encode(["success" => true, "filepath" => $file_path]);
} else {
    echo json_encode(["success" => false, "error" => "Failed to save file"]);
}
?>
