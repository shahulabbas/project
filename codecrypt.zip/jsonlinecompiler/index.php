<?php
session_start();
if (!isset($_SESSION['username'])) { header("Location: ../code/signin.html"); exit(); }
$user = $_SESSION['username'];
$firstname = isset($_SESSION['first_name']) && isset($_SESSION['last_name']) ? $_SESSION['first_name'].' '.$_SESSION['last_name'] : "User";
$profilePic = isset($_SESSION['profile_pic']) ? $_SESSION['profile_pic'] : "profile/default.png";
$userid = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>JavaScript Online Compiler | Code Crypt</title>
          <link rel="icon" type="image/x-icon" href="../images/logo.jpeg">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.5/codemirror.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.5/theme/dracula.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.5/codemirror.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.5/mode/javascript/javascript.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.5/addon/edit/matchbrackets.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.5/addon/edit/closebrackets.min.js"></script>
<style>
:root{
  --bg-0:#070a13;--bg-1:#0d1220;--bg-2:#131a2c;--surface:#171f34;--surface-2:#1e2743;
  --border:rgba(148,163,184,.14);--border-strong:rgba(148,163,184,.28);
  --text:#e8edf7;--muted:#8b95b0;
  --js-1:#F7DF1E;--js-2:#F0B90B;--js-glow:rgba(247,223,30,.35);
  --success:#10b981;
  --grad-js:linear-gradient(135deg,#F7DF1E 0%,#F0B90B 100%);
}
*{margin:0;padding:0;box-sizing:border-box}
html,body{background:var(--bg-0);color:var(--text);font-family:'Inter',sans-serif;min-height:100vh}
body{background:
  radial-gradient(1000px 500px at 10% -10%,rgba(247,223,30,.12),transparent 60%),
  radial-gradient(900px 500px at 110% 10%,rgba(240,185,11,.10),transparent 60%),
  var(--bg-0);}
.header-1{
    display:flex;justify-content:space-between;align-items:center;
    padding:20px 40px;
  }
  .logo-section{display:flex;align-items:center;gap:14px}
  .logo-box{
    width:56px;height:56px;border-radius:16px;background:var(--grad);
    display:flex;align-items:center;justify-content:center;box-shadow:var(--shadow);
    overflow:hidden;
  }
  .logo-box img{width:100%;height:100%;object-fit:cover}
  .logo-section h2{font-size:18px;font-weight:800;letter-spacing:1px;line-height:1.2}
  .logo-section h2 span{display:block;font-size:12px;font-weight:400;color:var(--muted);letter-spacing:.3px}
  .profile-section{
    display:flex;align-items:center;gap:12px;padding:8px 16px 8px 8px;border-radius:999px;
    background:var(--panel);border:1px solid var(--border);cursor:pointer;transition:.2s;
  }
  .profile-section:hover{background:var(--panel-2);border-color:var(--border-strong)}
  .profile-section img{width:40px;height:40px;border-radius:50%;object-fit:cover}
  .profile-section h2{font-size:14px;font-weight:600}
  .profile-section .status{font-size:11px;color:green;display:flex;align-items:center;gap:4px}
  .profile-section .status::before{content:"";width:6px;height:6px;background:green;border-radius:50%}

.main-section{
    display:grid;grid-template-columns:1fr;gap:24px;
    padding:0 40px;max-width:1400px;margin:0 auto;
  }

  /* Hero row: title + languages */
  .hero-card{
    background:linear-gradient(180deg,rgba(28,28,61,.6),rgba(22,22,50,.6));
    border:1px solid var(--border);border-radius:24px;padding:32px;
    display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:24px;
  }
  .hero-left .chip{
    display:inline-block;padding:6px 14px;border-radius:999px;
    background:var(--grad-soft);border:1px solid rgba(99,102,241,.3);
    color:#a5b4fc;font-size:12px;font-weight:600;margin-bottom:14px;
  }
  .hero-left h1{font-size:32px;font-weight:800;letter-spacing:-.5px}
  .hero-left h1 span{background:linear-gradient(135deg,#6366f1 0%,#8b5cf6 100%);-webkit-background-clip:text;background-clip:text;color:transparent}
  .hero-left p{color:var(--muted);margin-top:6px;font-size:14px}

  /* Language picker */
  .lang-sec{display:flex;gap:12px;flex-wrap:wrap;justify-content:space-between;align-items:center;padding:0}
  .lang-sec .lang{
    width:76px;height:76px;border-radius:16px;background:var(--panel);
    border:1px solid var(--border);display:flex;flex-direction:column;align-items:center;justify-content:center;
    gap:4px;cursor:pointer;transition:.25s;position:relative;
  }
  .lang-sec .lang:hover{transform:translateY(-3px);border-color:rgba(139,92,246,.5)}
  .lang-sec .lang img{width:34px;height:34px;object-fit:contain}
  .lang-sec .lang small{font-size:10px;color:var(--muted);font-weight:500}
  .lang-sec .lang.active{background:var(--grad);border-color:transparent;box-shadow:var(--shadow)}
  .lang-sec .lang.active small{color:#fff}

.platform{background:linear-gradient(180deg,var(--bg-1),var(--bg-2));border:1px solid var(--border);
  border-radius:22px;padding:22px;display:grid;grid-template-columns:1.5fr 1fr;gap:20px;min-height:calc(100vh - 140px)}
.language{grid-column:1 / -1;display:flex;align-items:center;justify-content:space-between;gap:16px;
  padding:18px 22px;border-radius:18px;position:relative;overflow:hidden}
.language::before{content:"";position:absolute;;
  background:radial-gradient(500px 200px at 90% 50%,rgba(255,255,255,.2),transparent 60%)}
.language h2{font-size:22px;font-weight:800;z-index:1;display:flex;align-items:center;gap:10px}
.language>img{width:56px;height:56px;border-radius:50%;border:3px solid rgba(0,0,0,.2);z-index:1;background:#fff}
.execute{display:flex;gap:10px;z-index:1}
.execute button{padding:10px 18px;border:none;border-radius:10px;font-weight:600;cursor:pointer;
  font-family:inherit;font-size:14px;display:inline-flex;align-items:center;gap:8px;transition:.2s;
  background:rgba(0,0,0,.75);color:#fff;border:1px solid rgba(0,0,0,.4)}
.execute button:hover{background:#000;transform:translateY(-1px)}

.code-window{background:var(--bg-0);border:1px solid var(--border);border-radius:16px;overflow:hidden;display:flex;flex-direction:column}
.win-bar{display:flex;align-items:center;gap:10px;padding:10px 14px;background:var(--surface);border-bottom:1px solid var(--border)}
.win-bar .dots{display:flex;gap:6px}
.win-bar .dots span{width:12px;height:12px;border-radius:50%}
.win-bar .dots span:nth-child(1){background:#ff5f57}
.win-bar .dots span:nth-child(2){background:#febc2e}
.win-bar .dots span:nth-child(3){background:#28c840}
.win-bar .filename{font-family:'JetBrains Mono',monospace;font-size:13px;color:var(--muted)}
.CodeMirror{height:auto !important;min-height:460px;font-family:'JetBrains Mono',monospace !important;font-size:14px;flex:1}

.side-panel{display:flex;flex-direction:column;gap:16px}
.io-card{background:var(--surface);border:1px solid var(--border);border-radius:16px;overflow:hidden;display:flex;flex-direction:column;flex:1}
.io-card h3{padding:12px 16px;font-size:13px;font-weight:600;text-transform:uppercase;letter-spacing:1px;
  color:var(--muted);background:var(--surface-2);border-bottom:1px solid var(--border);display:flex;align-items:center;gap:8px}
.io-card h3 i{color:var(--js-1)}
#output{flex:1;padding:16px;font-family:'JetBrains Mono',monospace;font-size:13px;color:#fde68a;
  background:var(--bg-0);white-space:pre-wrap;overflow-y:auto;min-height:220px;max-height:420px;margin:0}

@media (max-width:900px){
  .main-section{grid-template-columns:1fr}
  .lang-sec{flex-direction:row;overflow-x:auto;position:static}
  .platform{grid-template-columns:1fr}
  .language{flex-wrap:wrap}
}
</style>
</head>
<body>
<header class="header-1">
  <div class="logo-section">
    <div class="logo-box"><img src="../images/logo.jpeg" alt="Logo"></div>
    <h2>CODE CRYPT<span>Developer's Option</span></h2>
  </div>
  <div class="profile-section" onclick="togglePopup && togglePopup()">
    <img src="../code/<?php echo $profilePic; ?>" alt="">
    <div>
      <h2><?php echo $firstname; ?></h2>
      <div class="status">Online</div>
    </div>
  </div>
</header>


<main class="main-section">

  <section class="lang-sec">
    <div class="hero-left">
      <span class="chip">Welcome back</span>
      <h1>Hey, <span><?php echo $firstname; ?></span> 👋</h1>
      <p>Write, run and save code across languages — right in your browser.</p>
    </div>
    <div class="lang-sec">
      <div class="lang" onclick="python()"><img src="../images/python.png"><small>Python</small></div>
      <div class="lang" onclick="java()"><img src="../images/java.png"><small>Java</small></div>
      <div class="lang" onclick="php()"><img src="../images/php.png"><small>PHP</small></div>
      <div class="lang" onclick="html()"><img src="../images/html.png"><small>HTML</small></div>
      <div class="lang " style="background:linear-gradient(135deg,#6366f1 0%,#8b5cf6 100%);color:#fff" onclick="js()"><img src="../images/js.png"><small>JS</small></div>
      <div class="lang" onclick="c()"><img src="../images/c.png"><small>C</small></div>
      <div class="lang" onclick="cpp()"><img src="../images/cpp.png"><small>C++</small></div>
    </div></section>

  <section class="platform">
    <div class="language">
      <h2><i class="fa-brands fa-js"></i> JavaScript Programming</h2>
      <div class="execute">
        <button onclick="executeCode()" style="background:linear-gradient(135deg, #22c55e, #16a34a);"><i class="fa-solid fa-play"></i> Run</button>
        <button onclick="saveCode()" style="background:linear-gradient(135deg, #3b82f6, #1d4ed8);"><i class="fa-solid fa-floppy-disk"></i> Save</button>
        <button onclick="goHome()"><i class="fa-solid fa-house"></i> Home</button>
      </div>
    </div>

    <div class="code-window">
      <div class="win-bar">
        <div class="dots"><span></span><span></span><span></span></div>
        <div class="filename">script.js</div>
      </div>
      <textarea id="editor">// Write your JavaScript here
console.log("Hello, World!");</textarea>
    </div>

    <div class="side-panel">
      <div class="io-card">
        <h3><i class="fa-solid fa-terminal"></i> Output</h3>
        <pre id="output">// Run your code to see the output</pre>
      </div>
    </div>
  </section>
</section>

<script>
var editor = CodeMirror.fromTextArea(document.getElementById("editor"),{
  mode:"javascript",theme:"dracula",lineNumbers:true,indentUnit:2,
  matchBrackets:true,autoCloseBrackets:true,lineWrapping:true
});

function executeCode(){
  let code = editor.getValue();
  let out = document.getElementById("output");
  out.textContent = "Running...";
  fetch('execute.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body:'code='+encodeURIComponent(code)})
    .then(r=>r.text()).then(d=>out.textContent=d||"(no output)")
    .catch(e=>out.textContent="Error: "+e);
}

function saveCode(){
  let code = editor.getValue();
  let filename = prompt("Enter filename:","script.js");
  if(!filename) return;
  fetch('save.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body:'filename='+encodeURIComponent(filename)+'&code='+encodeURIComponent(code)})
    .then(r=>r.text()).then(d=>alert(d))
    .catch(e=>alert("Error saving file: "+e));
}

function python(){location.href='../flask_project/index.php'}
function java(){location.href='../java/java.php'}
function php(){location.href='../php/index.php'}
function js(){location.href='../jsonlinecompiler/index.php'}
function html(){location.href='../web/index.php'}
function c(){location.href='../c/index.php'}
function cpp(){location.href='../cpponlinecompiler/index.php'}
function goHome(){location.href='../code/home.php'}
</script>
</body>
</html>
