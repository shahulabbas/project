<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: ../code/signin.html");
    exit();
}

$user = $_SESSION['username'];
$firstname = isset($_SESSION['first_name']) && isset($_SESSION['last_name']) ? $_SESSION['first_name'] . ' ' . $_SESSION['last_name'] : "User";
$profilePic = isset($_SESSION['profile_pic']) ? $_SESSION['profile_pic'] : "profile/default.png";
$userid = $_SESSION['user_id'];

$saved_dir = "../flask_project/saved_files/$userid";
if (!file_exists($saved_dir)) {
    mkdir($saved_dir, 0777, true);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $code = isset($_POST["code"]) ? $_POST["code"] : "";
    $filename = isset($_POST["filename"]) ? preg_replace('/[^a-zA-Z0-9-_]/', '', $_POST["filename"]) : "Main";
    $inputData = isset($_POST["input"]) ? $_POST["input"] : "";

    $javaFile = "$saved_dir/$filename.java";
    file_put_contents($javaFile, $code);

    $inputFile = "$saved_dir/input.txt";
    file_put_contents($inputFile, $inputData);

    $compile = shell_exec("javac $javaFile 2>&1");

    if ($compile) {
        $output = "Compilation Error:\n" . $compile;
    } else {
        $output = shell_exec("java -cp $saved_dir $filename < $inputFile 2>&1");
    }

    echo json_encode(["output" => $output, "filepath" => $javaFile]);
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Java Compiler — Code Crypt</title>
          <link rel="icon" type="image/x-icon" href="../images/logo.jpeg">

<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.5/codemirror.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.5/mode/clike/clike.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.5/codemirror.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.5/theme/dracula.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
  *{box-sizing:border-box;margin:0;padding:0;font-family:'Inter',system-ui,sans-serif}
  :root{
    --bg:#0b0b1a; --panel:#161632; --panel-2:#1c1c3d;
    --border:rgba(255,255,255,.08); --border-strong:rgba(255,255,255,.14);
    --text:#eef0ff; --muted:#9ca3c7; --dim:#6b7099;
    --indigo:#6366f1; --violet:#8b5cf6; --green:#22c55e;
    --java:#f89820;
    --grad:linear-gradient(135deg,#6366f1 0%,#8b5cf6 100%);
    --grad-java:linear-gradient(135deg,#f89820 0%,#e76f00 100%);
    --grad-soft:linear-gradient(135deg,rgba(248,152,32,.18),rgba(83,130,161,.18));
    --shadow:0 20px 60px -20px rgba(99,102,241,.35);
    --shadow-java:0 20px 60px -20px rgba(248,152,32,.5);
  }
  html,body{background:var(--bg);color:var(--text);min-height:100vh}
  body{
    background:
      radial-gradient(1000px 500px at 90% 0%, rgba(139,92,246,.18), transparent 60%),
      radial-gradient(800px 400px at 0% 20%, rgba(99,102,241,.15), transparent 60%),
      var(--bg);
    padding-bottom:40px;text-align:left;
  }

  .header-1{display:flex;justify-content:space-between;align-items:center;padding:20px 40px}
  .logo-section{display:flex;align-items:center;gap:14px}
  .logo-box{
    width:56px;height:56px;border-radius:16px;background:var(--grad);
    display:flex;align-items:center;justify-content:center;box-shadow:var(--shadow);overflow:hidden;
  }
  .logo-box img{width:100%;height:100%;object-fit:cover}
  .logo-section h2{font-size:18px;font-weight:800;letter-spacing:1px;line-height:1.2}
  .logo-section h2 span{display:block;font-size:12px;font-weight:400;color:var(--muted);letter-spacing:.3px}
  .profile-section{
    display:flex;align-items:center;gap:12px;padding:8px 16px 8px 8px;border-radius:999px;
    background:var(--panel);border:1px solid var(--border);cursor:pointer;transition:.2s;
  }
  .profile-section:hover{background:var(--panel-2);border-color:var(--border-strong)}
  .profile-section img.profile-pic{width:40px;height:40px;border-radius:50%;object-fit:cover}
  .profile-section h2{font-size:14px;font-weight:600}
  .profile-section .status{font-size:11px;color:var(--green);display:flex;align-items:center;gap:4px}
  .profile-section .status::before{content:"";width:6px;height:6px;background:var(--green);border-radius:50%}

  .main-section{display:grid;grid-template-columns:1fr;gap:24px;padding:0 40px;max-width:1400px;margin:0 auto}

  .hero-card{
    background:linear-gradient(180deg,rgba(28,28,61,.6),rgba(22,22,50,.6));
    border:1px solid var(--border);border-radius:24px;padding:32px;
    display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:24px;
  }
  .hero-left .chip{
    display:inline-block;padding:6px 14px;border-radius:999px;
    background:var(--grad-soft);border:1px solid rgba(99,102,241,.3);
    color:#a5b4fc;font-size:12px;font-weight:600;margin-bottom:14px;
  }
  .hero-left h1{font-size:32px;font-weight:800;letter-spacing:-.5px}
  .hero-left h1 span{background:var(--grad);-webkit-background-clip:text;background-clip:text;color:transparent}
  .hero-left p{color:var(--muted);margin-top:6px;font-size:14px}

  /* Language picker */
  .lang-sec{display:flex;gap:12px;flex-wrap:wrap;justify-content:space-between;align-items:center;padding:0}
  .lang-sec .lang{
    width:76px;height:76px;border-radius:16px;background:var(--panel);
    border:1px solid var(--border);display:flex;flex-direction:column;align-items:center;justify-content:center;
    gap:4px;cursor:pointer;transition:.25s;position:relative;
  }
  .lang-sec .lang:hover{transform:translateY(-3px);border-color:rgba(139,92,246,.5)}
  .lang-sec .lang img{width:34px;height:34px;object-fit:contain}
  .lang-sec .lang small{font-size:10px;color:var(--muted);font-weight:500}
  .lang-sec .lang.active{background:var(--grad);border-color:transparent;box-shadow:var(--shadow)}
  .lang-sec .lang.active small{color:#fff}

  .platform{
    background:linear-gradient(180deg,rgba(28,28,61,.5),rgba(22,22,50,.5));
    border:1px solid var(--border);border-radius:24px;padding:24px;
  }
  .language{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:20px;flex-wrap:wrap}
  .language h2{font-size:22px;font-weight:700;display:flex;align-items:center;gap:12px;color:var(--text)!important}
  .language h2::before{
    content:"\f4e4";font-family:'Font Awesome 6 Free';font-weight:900;font-size:18px;
    width:44px;height:40px;border-radius:12px;background:var(--grad-soft);
    display:inline-flex;align-items:center;justify-content:center;color:var(--java);
  }
  .language > img{display:none}
  .execute{display:flex;gap:10px;flex-wrap:wrap}
  .execute button{
    padding:10px 18px;border:none;border-radius:12px;font-weight:600;font-size:14px;cursor:pointer;
    display:inline-flex;align-items:center;gap:8px;transition:.2s;color:#fff;font-family:inherit;margin:0;
    background:none;
  }
  .execute button:nth-child(1){box-shadow:var(--shadow-java)}
  .execute button:nth-child(1)::before{content:"\f04b";font-family:'Font Awesome 6 Free';font-weight:900}
  .execute button:nth-child(2){background:var(--grad)!important;box-shadow:var(--shadow)}
  .execute button:nth-child(2)::before{content:"\f0c7";font-family:'Font Awesome 6 Free';font-weight:900}
  .execute button:nth-child(3){background:var(--panel)!important;border:1px solid var(--border)!important;color:var(--text)}
  .execute button:nth-child(3)::before{content:"\f015";font-family:'Font Awesome 6 Free';font-weight:900}
  .execute button:hover{transform:translateY(-2px);filter:brightness(1.08)}

  .editor-grid{display:grid;grid-template-columns:1fr 380px;gap:20px}
  @media(max-width:960px){.editor-grid{grid-template-columns:1fr}}

  .code-window{background:#282a36;border:1px solid var(--border);border-radius:16px;overflow:hidden}
  .code-window-bar{
    display:flex;align-items:center;gap:8px;padding:12px 16px;
    background:rgba(0,0,0,.25);border-bottom:1px solid var(--border);
  }
  .code-window-bar .dot{width:12px;height:12px;border-radius:50%}
  .dot.r{background:#ff5f56}.dot.y{background:#ffbd2e}.dot.g{background:#27c93f}
  .code-window-bar .fname{margin-left:12px;font-size:12px;color:var(--muted);font-family:'JetBrains Mono',monospace}
  .CodeMirror{height:340px;font-family:'JetBrains Mono',monospace!important;font-size:14px;line-height:1.7}

  .side-panel{display:flex;flex-direction:column;gap:16px}
  .card{background:#0a0a1e;border:1px solid var(--border);border-radius:16px;overflow:hidden}
  .card-head{
    padding:12px 16px;border-bottom:1px solid var(--border);
    display:flex;align-items:center;gap:8px;font-size:13px;font-weight:600;color:var(--muted);
  }
  .card-head i{color:var(--java)}
  #inputArea{
    width:100%!important;min-height:130px;padding:14px;border:none;outline:none;resize:vertical;
    background:transparent;color:#eef0ff;font-family:'JetBrains Mono',monospace;font-size:13px;line-height:1.6;
    height:auto;overflow-y:auto;margin:0;
  }
  #output{
    padding:14px;min-height:170px;color:#86efac;font-family:'JetBrains Mono',monospace;font-size:13px;
    white-space:pre-wrap;line-height:1.6;background:transparent!important;border:none;width:100%!important;margin:0;height:auto;overflow-y:auto;border-radius:0;
  }
  #output:empty::before{content:"// Run your program to see output here";color:var(--dim);font-style:italic}

  ::placeholder{color:var(--dim)}

  /* Popup */
  .overlay{position:fixed;inset:0;background:rgba(0,0,0,.7);display:none;z-index:99;backdrop-filter:blur(6px)}
  .popupp{
    display:none;position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);
    background:var(--panel);color:var(--text);padding:24px;border-radius:20px;z-index:200;
    border:1px solid var(--border-strong);box-shadow:0 30px 80px -20px rgba(0,0,0,.6);width:min(420px,92vw);
  }
  .popupp h3{margin-bottom:16px;font-size:18px;font-weight:700;display:flex;align-items:center;gap:10px}
  .popupp h3::before{content:"\f0c7";font-family:'Font Awesome 6 Free';font-weight:900;color:var(--java)}
  .popupp input{
    width:100%;padding:12px 14px;margin:0 0 16px;border-radius:12px;
    background:#0a0a1e;border:1px solid var(--border);color:var(--text);font-family:inherit;font-size:14px;outline:none;
  }
  .popupp input:focus{border-color:var(--java)}
  .popupp .btn-row{display:flex;gap:10px}
  .popupp button{
    flex:1;padding:11px 18px;border:none;border-radius:12px;font-weight:600;cursor:pointer;
    font-family:inherit;font-size:14px;color:#fff;transition:.2s;
  }
  .popupp button.save-btn{background:var(--grad-java);box-shadow:var(--shadow-java)}
  .popupp button.close{background:var(--panel-2);border:1px solid var(--border)}
  .popupp button:hover{transform:translateY(-1px);filter:brightness(1.08)}

  @media(max-width:640px){
    .header-1,.main-section{padding-left:20px;padding-right:20px}
  }
</style>
</head>
<body>
  <header class="header-1">
    <div class="logo-section">
      <div class="logo-box"><img src="../images/logo.jpeg" alt="Logo"></div>
      <h2>CODE CRYPT<span>Developer's Option</span></h2>
    </div>
    <div class="profile-section" onclick="togglePopup()">
      <img src="../code/<?php echo $profilePic; ?>" alt="Profile Picture" class="profile-pic">
      <div>
        <h2><?php echo $firstname; ?></h2>
        <div class="status">Online</div>
      </div>
    </div>
  </header>

  <section class="main-section">
    <section class="lang-sec">

    <div class="hero-left">
      <span class="chip">Welcome back</span>
      <h1>Hey, <span><?php echo $firstname; ?></span> 👋</h1>
      <p>Write, run and save code across languages — right in your browser.</p>
    </div>
    <div class="lang-sec">
      <div class="lang" onclick="python()"><img src="../images/python.png"><small>Python</small></div>
      <div class="lang active" onclick="java()"><img src="../images/java.png"><small>Java</small></div>
      <div class="lang" onclick="php()"><img src="../images/php.png"><small>PHP</small></div>
      <div class="lang" onclick="html()"><img src="../images/html.png"><small>HTML</small></div>
      <div class="lang" onclick="js()"><img src="../images/js.png"><small>JS</small></div>
      <div class="lang" onclick="c()"><img src="../images/c.png"><small>C</small></div>
      <div class="lang" onclick="cpp()"><img src="../images/cpp.png"><small>C++</small></div>
    </div></section>

    <div class="overlay" id="overlay" onclick="closeSavePopup()"></div>

    <section class="platform">
      <div class="language">
        <h2>Java Programming</h2>
        <div class="execute">
          <button onclick="executeCode()" style="background:linear-gradient(135deg, #22c55e, #16a34a);">Run</button>
          <button onclick="openSavePopup()">Save</button>
          <button onclick="goHome()">Home</button>
        </div>
        <img src="../images/java1.png" alt="">
      </div>

      <div class="editor-grid">
        <div class="code-window">
          <div class="code-window-bar">
            <span class="dot r"></span><span class="dot y"></span><span class="dot g"></span>
            <span class="fname">Main.java</span>
          </div>
          <textarea id="editor">public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}</textarea>
        </div>

        <div class="side-panel">
          <div class="card">
            <div class="card-head"><i class="fa-solid fa-keyboard"></i> Standard Input (runtime input)</div>
            <textarea id="inputArea" placeholder="Enter input here..."></textarea>
          </div>
          <div class="card">
            <div class="card-head"><i class="fa-solid fa-terminal"></i> Output</div>
            <pre id="output"></pre>
          </div>
        </div>
      </div>
    </section>
  </section>

  <div class="popupp" id="savePopup">
    <h3>Save Java File</h3>
    <input type="text" id="filename" placeholder="Enter file name (e.g. Main)" required>
    <div class="btn-row">
      <button class="save-btn" onclick="saveFile()">Save</button>
      <button class="close" onclick="closeSavePopup()">Cancel</button>
    </div>
  </div>

  <script>
    const editor = CodeMirror.fromTextArea(document.getElementById("editor"), {
      mode: "text/x-java",
      theme: "dracula",
      lineNumbers: true,
      indentUnit: 4,
      tabSize: 4,
      matchBrackets: true,
      autoCloseBrackets: true
    });

    function executeCode() {
      const code = editor.getValue();
      const input = document.getElementById("inputArea").value;
      document.getElementById("output").innerText = "Running...";
      fetch("execute.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "code=" + encodeURIComponent(code) + "&input=" + encodeURIComponent(input)
      })
        .then(response => response.json())
        .then(data => { document.getElementById("output").innerText = data.output; })
        .catch(error => document.getElementById("output").innerText = "Error: " + error);
    }

    function openSavePopup(){
      document.getElementById("savePopup").style.display="block";
      document.getElementById("overlay").style.display="block";
    }
    function closeSavePopup(){
      document.getElementById("savePopup").style.display="none";
      document.getElementById("overlay").style.display="none";
    }

    function saveFile() {
      const code = editor.getValue();
      const filename = document.getElementById("filename").value;
      if(!filename){ alert("Please enter a file name."); return; }
      fetch("", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "filename=" + encodeURIComponent(filename) + "&code=" + encodeURIComponent(code)
      })
        .then(response => response.json())
        .then(data => {
          if (data.filepath) { alert("File saved successfully: " + data.filepath); closeSavePopup(); }
          else { alert("Error saving file."); }
        })
        .catch(error => console.error("Error:", error));
    }

    function togglePopup(){ /* profile menu hook */ }
    function python(){ window.location.href='../flask_project/index.php'; }
    function java(){ window.location.href='../java/java.php'; }
    function php(){ window.location.href='../php/index.php'; }
    function js(){ window.location.href='../jsonlinecompiler/index.php'; }
    function html(){ window.location.href='../web/index.php'; }
    function c(){ window.location.href='../c/index.php'; }
    function cpp(){ window.location.href='../cpponlinecompiler/index.php'; }
    function goHome(){ window.location.href='../code/home.php'; }
  </script>
</body>
</html>
