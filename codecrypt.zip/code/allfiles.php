<?php
session_start();

// Redirect to login if not authenticated
if (!isset($_SESSION['username'])) {
    header("Location: ./signin.html");
    exit();
}
$user = $_SESSION['username'];
$firstname = isset($_SESSION['first_name']) && isset($_SESSION['last_name']) ? $_SESSION['first_name'] . ' ' . $_SESSION['last_name'] : "User";
$profilePic = isset($_SESSION['profile_pic']) ? $_SESSION['profile_pic'] : "profile/default.png";
$userid = $_SESSION['user_id'];
// Define the main folder path
$mainFolderPath = "../flask_project/saved_files"; // Adjust as needed
$sessionId = $_SESSION['user_id'];
$folderPath = $mainFolderPath . '/' . $sessionId;

// Check if a file is selected for viewing
$selectedFile = isset($_GET['file']) ? basename($_GET['file']) : null;
$fileContent = "";

// If a file is selected, read its content
if ($selectedFile) {
    $filePath = $folderPath . '/' . $selectedFile;
    if (file_exists($filePath)) {
        $fileContent = htmlspecialchars(file_get_contents($filePath));
    } else {
        $fileContent = "File not found.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Project</title>
    <link rel="stylesheet" href="../flask_project/style.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="home.css?v=<?php echo time(); ?>">
    <style>
    body {
        font-family: Arial, sans-serif;
        display: flex;
        height: 100vh;
        margin: 0;
        flex-direction: column;
        color: #fff;
        background: #1C2130;
    }

    .header-1 {
        color: #fff;
    }

    .container {
        display: flex;
        width: 100%;
        height: 100%;
    }

    .file-list {
        width: 30%;
        padding: 20px;
        border-right: 1px solid #ddd;
        overflow-y: scroll;
        background: #1E2A3A;

    }

    .file-list::-webkit-scrollbar {
        display: none;
    }

    .file-content {
        width: 70%;
        padding: 20px;
        overflow-y: auto;
    }

    ul {
        list-style: none;
        padding: 0;

    }

    li {
        margin: 10px 0;
        padding: 10px;
        color: #000;
        background: #fff;
    }

    a {
        text-decoration: none;
        font-weight: bold;
        display: block;
    }

    a:hover {
        color: #0056b3;
    }

    pre {
        background: #1E2A3A;
        padding: 15px;
        border: 1px solid #ddd;
        border-radius: 5px;
        overflow-x: auto;
        white-space: pre-wrap;
        height: 100%;
        color: #fff;
        margin: 20px 0;
    }
    .profile-pic{
        height:70px;
        width:70px;
    }
    </style>
</head>

<body>
    <header class="header-1">
        <div class="logo-section">
            <img src="../images/logo.jpeg" alt="Logo">
            <h2>CODE CRYPT <br> Developers Option</h2>
        </div>

        <div class="profile-section" onclick="togglePopup()">
            <img src="../code/<?php echo $profilePic; ?>" alt="Profile Picture" class="profile-pic">
            <h2><?php echo $firstname; ?></h2>
        </div>
    </header>
    <div class="container">
        <div class="file-list">
            <h2>All Projects</h2>
            <?php if (is_dir($folderPath)): ?>
            <ul>
                <?php
                    $files = scandir($folderPath);
                    foreach ($files as $file) {
                        if ($file !== '.' && $file !== '..') {
                            echo "<li><a href='?file=" . urlencode($file) . "'>$file</a></li>";
                        }
                    }
                    ?>
            </ul>
            <?php else: ?>
            <p><strong>Folder not found.</strong></p>
            <?php endif; ?>
        </div>
        <div class="file-content">
            <?php if ($selectedFile): ?>
            <div class="execute" style="width:100%;">

                <h2>File: <?php echo htmlspecialchars($selectedFile); ?></h2>
                <button onclick="goHome()">Home</button> <!-- Home Button -->
            </div>
            <pre><?php echo $fileContent; ?></pre>
            <?php else: ?>
            <p>Select a file to view its contents.</p>
            <?php endif; ?>
        </div>
    </div>
    <script>
    function goHome() {
        window.location.href = "./home.php"; // Change this to your actual homepage URL
    }
    </script>
</body>

</html>