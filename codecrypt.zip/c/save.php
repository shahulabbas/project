<?php
session_start();
$userid = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : "guest";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $filename = preg_replace("/[^a-zA-Z0-9_\-\.]/", "", $_POST["filename"]); // Sanitize filename
    $code = $_POST["code"];
    
    // Define the folder
    $folder = "../flask_project/saved_files/$userid";
    
    // Create folder if it doesn't exist
    if (!is_dir($folder)) {
        mkdir($folder, 0777, true);
    }

    // Save the file
    $filepath = "$folder/$filename";
    
    if (file_put_contents($filepath, $code)) {
        echo "File saved successfully: " . htmlspecialchars($filepath);
    } else {
        echo "Error saving file.";
    }
} else {
    echo "Invalid request.";
}
?>
