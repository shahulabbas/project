<?php
header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['code'])) {
    echo json_encode(["output" => "No code received."]);
    exit;
}

$code = $data['code'];
$stdin = isset($data['stdin']) ? $data['stdin'] : "";

// JDoodle API credentials
$client_id = "a07f369753f34bc4f305f3f1fcf73bdd";  // Replace with your JDoodle Client ID
$client_secret = "2a8d8140422f67031a0c8038fd74643109c7b2263a90766d9272aaeba54fffe4";  // Replace with your JDoodle Client Secret
$api_url = "https://api.jdoodle.com/v1/execute";

$payload = [
    "script" => $code,
    "language" => "cpp",
    "versionIndex" => "0",
    "clientId" => $client_id,
    "clientSecret" => $client_secret,
    "stdin" => $stdin  // Sending input to JDoodle
];

$options = [
    "http" => [
        "header" => "Content-Type: application/json\r\n",
        "method" => "POST",
        "content" => json_encode($payload)
    ]
];

$context = stream_context_create($options);
$response = file_get_contents($api_url, false, $context);

if ($response === FALSE) {
    echo json_encode(["output" => "Error executing code."]);
} else {
    echo $response;
}
?>
