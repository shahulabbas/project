<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $code = $_POST["code"];

    $folder = "temp_code/";
    if (!is_dir($folder)) {
        mkdir($folder, 0777, true);
    }

    $filename = $folder . "script_" . uniqid() . ".js";
    file_put_contents($filename, $code);

    $output = shell_exec("node \"$filename\" 2>&1");

    unlink($filename);

    echo $output;   // <-- No nl2br(), no htmlspecialchars()
} else {
    echo "Invalid request.";
}
?>