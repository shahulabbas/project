<?php
session_start();
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (empty($username) || empty($password)) {
        die("Error: Please fill all fields.");
    }

    try {

        // Get user details
        $stmt = $conn->prepare("
            SELECT id, password, first_name, last_name, profile_pic
            FROM users
            WHERE username = :username
        ");

        $stmt->execute([
            ':username' => $username
        ]);

        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {

            if (password_verify($password, $user['password'])) {

                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $username;
                $_SESSION['first_name'] = $user['first_name'];
                $_SESSION['last_name'] = $user['last_name'];
                $_SESSION['profile_pic'] = $user['profile_pic'];

                header("Location: home.php");
                exit();

            } else {

                echo "<script>
                        alert('Incorrect password.');
                        window.location.href='signin.html';
                      </script>";

            }

        } else {

            echo "<script>
                    alert('User not found.');
                    window.location.href='signin.html';
                  </script>";

        }

    } catch (PDOException $e) {

        die("Database Error: " . $e->getMessage());

    }

} else {

    die("Invalid Request.");

}
?>