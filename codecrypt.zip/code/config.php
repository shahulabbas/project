<?php

$host = "db.tmnnzhdwvciblwttgslw.supabase.co";
$port = "5432";
$dbname = "postgres";
$user = "postgres";
$password = "shaly_official.baby";

try {
    $conn = new PDO(
        "pgsql:host=$host;port=$port;dbname=$dbname;sslmode=require",
        $user,
        $password
    );

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {
    die(json_encode([
        "success" => false,
        "message" => "Database Connection Failed: " . $e->getMessage()
    ]));
}

?>