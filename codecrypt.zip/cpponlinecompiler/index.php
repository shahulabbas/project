<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: ../code/signin.html");
    exit();
}

$user = $_SESSION['username'];
$firstname = isset($_SESSION['first_name']) && isset($_SESSION['last_name']) ? $_SESSION['first_name'] . ' ' . $_SESSION['last_name'] : "User";
$profilePic = isset($_SESSION['profile_pic']) ? $_SESSION['profile_pic'] : "profile/default.png";
$userid = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>C++ Compiler — Code Crypt</title>
          <link rel="icon" type="image/x-icon" href="../images/logo.jpeg">

<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.5/codemirror.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.5/mode/clike/clike.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.5/codemirror.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.5/theme/dracula.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
  *{box-sizing:border-box;margin:0;padding:0;font-family:'Inter',system-ui,sans-serif}
  :root{
    --bg:#0b0b1a; --panel:#161632; --panel-2:#1c1c3d;
    --border:rgba(255,255,255,.08); --border-strong:rgba(255,255,255,.14);
    --text:#eef0ff; --muted:#9ca3c7; --dim:#6b7099;
    --indigo:#6366f1; --violet:#8b5cf6; --green:#22c55e;
    --grad:linear-gradient(135deg,#6366f1 0%,#8b5cf6 100%);
    --grad-soft:linear-gradient(135deg,rgba(99,102,241,.15),rgba(139,92,246,.15));
    --shadow:0 20px 60px -20px rgba(99,102,241,.35);
  }
  html,body{background:var(--bg);color:var(--text);min-height:100vh}
  body{
    background:
      radial-gradient(1000px 500px at 90% 0%, rgba(139,92,246,.18), transparent 60%),
      radial-gradient(800px 400px at 0% 20%, rgba(99,102,241,.15), transparent 60%),
      var(--bg);
    padding-bottom:40px;text-align:left;
  }

  /* Header */
.header-1{
    display:flex;justify-content:space-between;align-items:center;
    padding:20px 40px;
  }
  .logo-section{display:flex;align-items:center;gap:14px}
  .logo-box{
    width:56px;height:56px;border-radius:16px;background:var(--grad);
    display:flex;align-items:center;justify-content:center;box-shadow:var(--shadow);
    overflow:hidden;
  }
  .logo-box img{width:100%;height:100%;object-fit:cover}
  .logo-section h2{font-size:18px;font-weight:800;letter-spacing:1px;line-height:1.2}
  .logo-section h2 span{display:block;font-size:12px;font-weight:400;color:var(--muted);letter-spacing:.3px}
  .profile-section{
    display:flex;align-items:center;gap:12px;padding:8px 16px 8px 8px;border-radius:999px;
    background:var(--panel);border:1px solid var(--border);cursor:pointer;transition:.2s;
  }
  .profile-section:hover{background:var(--panel-2);border-color:var(--border-strong)}
  .profile-section img{width:40px;height:40px;border-radius:50%;object-fit:cover}
  .profile-section h2{font-size:14px;font-weight:600}
  .profile-section .status{font-size:11px;color:var(--green);display:flex;align-items:center;gap:4px}
  .profile-section .status::before{content:"";width:6px;height:6px;background:var(--green);border-radius:50%}

  .main-section{
    display:grid;grid-template-columns:1fr;gap:24px;
    padding:0 40px;max-width:1400px;margin:0 auto;
  }

  /* Hero row: title + languages */
  .hero-card{
    background:linear-gradient(180deg,rgba(28,28,61,.6),rgba(22,22,50,.6));
    border:1px solid var(--border);border-radius:24px;padding:32px;
    display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:24px;
  }
  .hero-left .chip{
    display:inline-block;padding:6px 14px;border-radius:999px;
    background:var(--grad-soft);border:1px solid rgba(99,102,241,.3);
    color:#a5b4fc;font-size:12px;font-weight:600;margin-bottom:14px;
  }
  .hero-left h1{font-size:32px;font-weight:800;letter-spacing:-.5px}
  .hero-left h1 span{background:var(--grad);-webkit-background-clip:text;background-clip:text;color:transparent}
  .hero-left p{color:var(--muted);margin-top:6px;font-size:14px}

  /* Language picker */
  .lang-sec{display:flex;gap:12px;flex-wrap:wrap;justify-content:space-between;align-items:center}
  .lang-sec .lang{
    width:76px;height:76px;border-radius:16px;background:var(--panel);
    border:1px solid var(--border);display:flex;flex-direction:column;align-items:center;justify-content:center;
    gap:4px;cursor:pointer;transition:.25s;position:relative;
  }
  .lang-sec .lang:hover{transform:translateY(-3px);border-color:rgba(139,92,246,.5)}
  .lang-sec .lang img{width:34px;height:34px;object-fit:contain}
  .lang-sec .lang small{font-size:10px;color:var(--muted);font-weight:500}
  .lang-sec .lang.active{background:var(--grad);border-color:transparent;box-shadow:var(--shadow)}
  .lang-sec .lang.active small{color:#fff}

  /* Platform card */
  .platform{
    background:linear-gradient(180deg,rgba(28,28,61,.5),rgba(22,22,50,.5));
    border:1px solid var(--border);border-radius:24px;padding:24px;
  }
  .language{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:20px;flex-wrap:wrap}
  .language h1{font-size:22px;font-weight:700;display:flex;align-items:center;gap:12px}
  .language h1::before{
    content:"C++";font-family:'JetBrains Mono',monospace;font-size:14px;
    width:44px;height:40px;border-radius:12px;background:var(--grad-soft);
    display:inline-flex;align-items:center;justify-content:center;color:#a5b4fc;font-weight:700;
  }
  .language > img{display:none}
  .execute{display:flex;gap:10px;flex-wrap:wrap}
  .execute button{
    padding:10px 18px;border:none;border-radius:12px;font-weight:600;font-size:14px;cursor:pointer;
    display:inline-flex;align-items:center;gap:8px;transition:.2s;color:#fff;font-family:inherit;margin:0;
  }
  .execute button:nth-child(1){background:linear-gradient(135deg,#22c55e,#16a34a);box-shadow:0 8px 20px -8px rgba(34,197,94,.5)}
  .execute button:nth-child(1)::before{content:"\f04b";font-family:'Font Awesome 6 Free';font-weight:900}
  .execute button:nth-child(2){background:var(--grad);box-shadow:var(--shadow)}
  .execute button:nth-child(2)::before{content:"\f0c7";font-family:'Font Awesome 6 Free';font-weight:900}
  .execute button:nth-child(3){background:var(--panel);border:1px solid var(--border)!important;color:var(--text)}
  .execute button:nth-child(3)::before{content:"\f015";font-family:'Font Awesome 6 Free';font-weight:900}
  .execute button:hover{transform:translateY(-2px);filter:brightness(1.08)}

  /* Editor + side */
  .editor-grid{display:grid;grid-template-columns:1fr 380px;gap:20px}
  @media(max-width:960px){.editor-grid{grid-template-columns:1fr}}

  .code-window{background:#282a36;border:1px solid var(--border);border-radius:16px;overflow:hidden}
  .code-window-bar{
    display:flex;align-items:center;gap:8px;padding:12px 16px;
    background:rgba(0,0,0,.25);border-bottom:1px solid var(--border);
  }
  .code-window-bar .dot{width:12px;height:12px;border-radius:50%}
  .dot.r{background:#ff5f56}.dot.y{background:#ffbd2e}.dot.g{background:#27c93f}
  .code-window-bar .fname{margin-left:12px;font-size:12px;color:var(--muted);font-family:'JetBrains Mono',monospace}
  .CodeMirror{height:340px;font-family:'JetBrains Mono',monospace!important;font-size:14px;line-height:1.7}

  .side-panel{display:flex;flex-direction:column;gap:16px}
  .card{background:#0a0a1e;border:1px solid var(--border);border-radius:16px;overflow:hidden}
  .card-head{
    padding:12px 16px;border-bottom:1px solid var(--border);
    display:flex;align-items:center;gap:8px;font-size:13px;font-weight:600;color:var(--muted);
  }
  .card-head i{color:#a5b4fc}
  #userInput{
    width:100%;min-height:130px;padding:14px;border:none;outline:none;resize:vertical;
    background:transparent;color:#eef0ff;font-family:'JetBrains Mono',monospace;font-size:13px;line-height:1.6;
    height:auto;overflow-y:auto;margin:0;
  }
  #output{
    padding:14px;min-height:170px;color:#86efac;font-family:'JetBrains Mono',monospace;font-size:13px;
    white-space:pre-wrap;line-height:1.6;background:transparent;border:none;width:100%;margin:0;height:auto;overflow-y:auto;
  }
  #output:empty::before{content:"// Run your program to see output here";color:var(--dim);font-style:italic}

  ::placeholder{color:var(--dim)}

  @media(max-width:640px){
    .header-1,.main-section{padding-left:20px;padding-right:20px}
  }
</style>
</head>
<body>
  <header class="header-1">
  <div class="logo-section">
    <div class="logo-box"><img src="../images/logo.jpeg" alt="Logo"></div>
    <h2>CODE CRYPT<span>Developer's Option</span></h2>
  </div>
  <div class="profile-section" onclick="togglePopup && togglePopup()">
    <img src="../code/<?php echo $profilePic; ?>" alt="">
    <div>
      <h2><?php echo $firstname; ?></h2>
      <div class="status">Online</div>
    </div>
  </div>
</header>

  <section class="main-section">
      <section class="lang-sec">

    <div class="hero-left">
      <span class="chip">Welcome back</span>
      <h1>Hey, <span><?php echo $firstname; ?></span> 👋</h1>
      <p>Write, run and save code across languages — right in your browser.</p>
    </div>
    <div class="lang-sec">
      <div class="lang" onclick="python()"><img src="../images/python.png"><small>Python</small></div>
      <div class="lang" onclick="java()"><img src="../images/java.png"><small>Java</small></div>
      <div class="lang" onclick="php()"><img src="../images/php.png"><small>PHP</small></div>
      <div class="lang" onclick="html()"><img src="../images/html.png"><small>HTML</small></div>
      <div class="lang" onclick="js()"><img src="../images/js.png"><small>JS</small></div>
      <div class="lang" onclick="c()"><img src="../images/c.png"><small>C</small></div>
      <div class="lang active" onclick="cpp()"><img src="../images/cpp.png"><small>C++</small></div>
    </div></section>

    <section class="platform">
      <div class="language">
        <h1>C++ Programming</h1>
        <div class="execute">
          <button onclick="executeCode()">Run</button>
          <button onclick="saveCode()">Save</button>
          <button onclick="goHome()">Home</button>
        </div>
        <img src="../images/cpp1.png" alt="">
      </div>

      <div class="editor-grid">
        <div class="code-window">
          <div class="code-window-bar">
            <span class="dot r"></span><span class="dot y"></span><span class="dot g"></span>
            <span class="fname">main.cpp</span>
          </div>
          <textarea id="editor">#include <iostream>
using namespace std;
int main() {
    string name;
    cout << "Enter your name: ";
    cin >> name;
    cout << "Hello, " << name << "!";
    return 0;
}</textarea>
        </div>

        <div class="side-panel">
          <div class="card">
            <div class="card-head"><i class="fa-solid fa-keyboard"></i> Standard Input (runtime input)</div>
            <textarea id="userInput" placeholder="Enter input here..."></textarea>
          </div>
          <div class="card">
            <div class="card-head"><i class="fa-solid fa-terminal"></i> Output</div>
            <pre id="output"></pre>
          </div>
        </div>
      </div>
    </section>
  </section>

  <script>
    const editor = CodeMirror.fromTextArea(document.getElementById("editor"), {
      mode: "text/x-c++src",
      theme: "dracula",
      lineNumbers: true,
      indentUnit: 4,
      tabSize: 4,
      matchBrackets: true,
      autoCloseBrackets: true
    });

    function executeCode() {
      const code = editor.getValue();
      const userInput = document.getElementById("userInput").value;
      document.getElementById("output").innerText = "Running...";
      fetch("execute.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: code, stdin: userInput })
      })
        .then(response => response.json())
        .then(data => {
          document.getElementById("output").innerText = data.output || "Error: " + (data.error || "Unknown error.");
        })
        .catch(error => document.getElementById("output").innerText = "Error: " + error);
    }

    function saveCode() {
      const code = editor.getValue();
      const filename = prompt("Enter filename:", "program.cpp");
      if (!filename) return;
      fetch("save.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "filename=" + encodeURIComponent(filename) + "&code=" + encodeURIComponent(code)
      })
        .then(response => response.text())
        .then(data => alert(data))
        .catch(error => alert("Error saving file: " + error));
    }

    function togglePopup(){}
    function python(){ window.location.href='../flask_project/index.php'; }
    function java(){ window.location.href='../java/java.php'; }
    function php(){ window.location.href='../php/index.php'; }
    function js(){ window.location.href='../jsonlinecompiler/index.php'; }
    function html(){ window.location.href='../web/index.php'; }
    function c(){ window.location.href='../c/index.php'; }
    function cpp(){ window.location.href='../cpponlinecompiler/index.php'; }
    function goHome(){ window.location.href='../code/home.php'; }
  </script>
</body>
</html>
