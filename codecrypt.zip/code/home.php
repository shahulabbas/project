<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: signin.html");
    exit();
}

$user_id = $_SESSION['user_id'];
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';
$first_name = isset($_SESSION['first_name']) ? $_SESSION['first_name'] : '';
$last_name = isset($_SESSION['last_name']) ? $_SESSION['last_name'] : '';
$profile_pic = isset($_SESSION['profile_pic']) && $_SESSION['profile_pic'] !== '' ? $_SESSION['profile_pic'] : 'profile/default.png';

if (empty($username) || empty($first_name) || empty($last_name)) {
    $stmt = $conn->prepare("SELECT username, first_name, last_name, profile_pic FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($db_username, $db_first_name, $db_last_name, $db_profile_pic);

    if ($stmt->fetch()) {
        $username = $db_username;
        $first_name = $db_first_name;
        $last_name = $db_last_name;
        $profile_pic = !empty($db_profile_pic) ? $db_profile_pic : 'profile/default.png';

        $_SESSION['username'] = $username;
        $_SESSION['first_name'] = $first_name;
        $_SESSION['last_name'] = $last_name;
        $_SESSION['profile_pic'] = $profile_pic;
    }

    $stmt->close();
}

$full_name = trim($first_name . ' ' . $last_name);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Home · Code Crypt</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
          <link rel="icon" type="image/x-icon" href="../images/logo.jpeg">

  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
  <link rel="stylesheet" href="home.css" />
</head>
<body>
  <header class="header">
    <div class="logo-section">
      <div class="logo-badge">&lt;/&gt;</div>
      <div>
        <h1>CODE CRYPT</h1>
        <span>Developer's Option</span>
      </div>
    </div>

    <div class="profile-section" onclick="togglePopup()">
      <img id="headerAvatar" src="<?php echo htmlspecialchars($profile_pic, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($username, ENT_QUOTES, 'UTF-8'); ?>" />
      <div class="profile-meta">
        <strong id="headerName"><?php echo htmlspecialchars($full_name, ENT_QUOTES, 'UTF-8'); ?></strong>
        <small>Online</small>
      </div>
      <i class="fa-solid fa-chevron-down"></i>
    </div>
  </header>

  <!-- Slide-in profile popup -->
  <aside class="popup" id="popupMenu">
    <div class="popup-head">
      <div class="popup-user">
        <img src="<?php echo htmlspecialchars($profile_pic, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($username, ENT_QUOTES, 'UTF-8'); ?>" />
        <div>
          <h3 id="popupUser"><?php echo htmlspecialchars($username, ENT_QUOTES, 'UTF-8'); ?></h3>
          <p id="popupFull"><?php echo htmlspecialchars($full_name, ENT_QUOTES, 'UTF-8'); ?></p>
        </div>
      </div>
      <button class="icon-btn" onclick="togglePopup()"><i class="fa-solid fa-xmark"></i></button>
    </div>

    <button class="popup-btn" onclick="openSubPopup('personalDetailsPopup')">
      <i class="fa-solid fa-user-pen"></i> Personal Details
    </button>
    <button class="popup-btn" onclick="location.href='allfiles.php'">
      <i class="fa-solid fa-folder-open"></i> All Projects
    </button>
    <button class="popup-btn" onclick="openModal('authModal')">
      <i class="fa-solid fa-key"></i> Authentication Change
    </button>
    <button class="popup-btn danger" onclick="location.href='logout.php'">
      <i class="fa-solid fa-right-from-bracket"></i> Logout
    </button>
  </aside>

  <!-- Auth modal -->
  <div class="modal" id="authModal">
    <div class="modal-head">
      <h3>Update Credentials</h3>
      <button class="icon-btn" onclick="closeModal('authModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <form class="modal-form" onsubmit="event.preventDefault(); closeModal('authModal');">
      <input type="text" placeholder="Current username" required />
      <input type="password" placeholder="Current password" required />
      <input type="text" placeholder="New username" required />
      <input type="password" placeholder="New password" required />
      <button class="primary-btn" type="submit">Save Changes</button>
    </form>
  </div>

  <!-- Personal details modal -->
  <div class="modal" id="personalDetailsPopup">
    <div class="modal-head">
      <h3>Update Personal Details</h3>
      <button class="icon-btn" onclick="closeSubPopup('personalDetailsPopup')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <form class="modal-form" onsubmit="event.preventDefault(); closeSubPopup('personalDetailsPopup');">
      <label>First Name<input type="text" required /></label>
      <label>Last Name<input type="text" required /></label>
      <label>Profile Picture<input type="file" accept="image/*" /></label>
      <button class="primary-btn" type="submit">Update</button>
    </form>
  </div>

  <div class="overlay" id="overlay" onclick="closeAll()"></div>

  <main class="main">
    <section class="hero">
      <div class="hero-copy">
        <span class="eyebrow">Welcome back</span>
        <h2>Hello, <span class="accent" id="heroName"><?php echo htmlspecialchars($first_name, ENT_QUOTES, 'UTF-8'); ?></span> 👋</h2>
        <h3>Your cloud coding workspace</h3>
        <p>Practice coding, store your work in the cloud, and reuse snippets across languages — all in one place.</p>
        <div class="hero-actions">
          <button class="primary-btn"><i class="fa-solid fa-play"></i> Start Coding</button>
          <button class="ghost-btn" onclick="location.href='allfiles.php'"><i class="fa-solid fa-folder"></i> My Projects</button>
        </div>
      </div>
      <div class="hero-art">
        <div class="code-card">
          <div class="dots"><span></span><span></span><span></span></div>
<pre><code><span class="k">def</span> <span class="fn">greet</span>(name):
    <span class="k">return</span> <span class="s">f"Hello, {name}!"</span>

<span class="c"># deploy to code crypt</span>
print(greet(<span class="s">"Alex"</span>))</code></pre>
        </div>
      </div>
    </section>

    <section class="languages">
      <h3 class="section-title">Pick a language</h3>
      <div class="lang-grid">
        <button class="lang-card" onclick="go('python')"><i class="fa-brands fa-python" style="color:#3776ab"></i><span>Python</span></button>
        <button class="lang-card" onclick="go('java')"><i class="fa-brands fa-java" style="color:#e76f00"></i><span>Java</span></button>
        <button class="lang-card" onclick="go('php')"><i class="fa-brands fa-php" style="color:#777bb3"></i><span>PHP</span></button>
        <button class="lang-card" onclick="go('html')"><i class="fa-brands fa-html5" style="color:#e34f26"></i><span>HTML</span></button>
        <button class="lang-card" onclick="go('js')"><i class="fa-brands fa-js" style="color:#f0db4f"></i><span>JavaScript</span></button>
        <button class="lang-card" onclick="go('c')"><i class="fa-solid fa-c" style="color:#5c6bc0"></i><span>C</span></button>
        <button class="lang-card" onclick="go('cpp')"><i class="fa-solid fa-code" style="color:#00599c"></i><span>C++</span></button>
      </div>
    </section>
  </main>

  <script>
const overlay = document.getElementById('overlay');

function togglePopup() {
  document.getElementById('popupMenu').classList.toggle('show');
}
function openSubPopup(id) {
  document.getElementById(id).classList.add('show');
  overlay.classList.add('show');
}
function closeSubPopup(id) {
  document.getElementById(id).classList.remove('show');
  overlay.classList.remove('show');
}
function openModal(id) {
  document.getElementById(id).classList.add('show');
  overlay.classList.add('show');
}
function closeModal(id) {
  document.getElementById(id).classList.remove('show');
  overlay.classList.remove('show');
}
function closeAll() {
  document.querySelectorAll('.modal.show').forEach(m => m.classList.remove('show'));
  overlay.classList.remove('show');
}

const routes = {
  python: '../flask_project/index.php',
  java: '../java/java.php',
  php: '../php/index.php',
  js: '../jsonlinecompiler/index.php',
  html: '../web/index.php',
  c: '../c/index.php',
  cpp: '../cpponlinecompiler/index.php'
};
function go(key) { window.location.href = routes[key]; }

  </script>
</body>
</html>
