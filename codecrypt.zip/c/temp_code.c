#include <stdio.h>
#include <string.h>

int main() {
    char str[100]; 
    char str1[50];
    int count = 0, count1 = 0;
    char vowels[] = "aeiouAEIOU";

    printf("Enter first string: ");
    fgets(str, sizeof(str), stdin);  // Read first input

    printf("Enter second string: ");
    fgets(str1, sizeof(str1), stdin); // Read second input

    // Count vowels in first string
    for (int i = 0; i < strlen(str); i++) {
        if (strchr(vowels, str[i])) {
            count++;
        }
    }

    // Count vowels in second string
    for (int i = 0; i < strlen(str1); i++) {
        if (strchr(vowels, str1[i])) {
            count1++;
        }
    }

    printf("Number of vowels in first string: %d\n", count);
    printf("Number of vowels in second string: %d\n", count1);

    return 0;
}
