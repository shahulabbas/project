<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: ../code/signin.html");
    exit();
}

$user = $_SESSION['username'];
$firstname = isset($_SESSION['first_name']) && isset($_SESSION['last_name']) ? $_SESSION['first_name'] . ' ' . $_SESSION['last_name'] : "User";
$profilePic = isset($_SESSION['profile_pic']) ? $_SESSION['profile_pic'] : "profile/default.png";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Python Compiler — Code Crypt</title>
          <link rel="icon" type="image/x-icon" href="../images/logo.jpeg">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
  *{box-sizing:border-box;margin:0;padding:0;font-family:'Inter',system-ui,sans-serif}
  :root{
    --bg:#0b0b1a;
    --bg-2:#0f0f24;
    --panel:#161632;
    --panel-2:#1c1c3d;
    --border:rgba(255,255,255,.08);
    --border-strong:rgba(255,255,255,.14);
    --text:#eef0ff;
    --muted:#9ca3c7;
    --dim:#6b7099;
    --indigo:#6366f1;
    --violet:#8b5cf6;
    --blue:#3b82f6;
    --green:#22c55e;
    --grad:linear-gradient(135deg,#6366f1 0%,#8b5cf6 100%);
    --grad-soft:linear-gradient(135deg,rgba(99,102,241,.15),rgba(139,92,246,.15));
    --shadow:0 20px 60px -20px rgba(99,102,241,.35);
  }
  html,body{background:var(--bg);color:var(--text);min-height:100vh}
  body{
    background:
      radial-gradient(1000px 500px at 90% 0%, rgba(139,92,246,.18), transparent 60%),
      radial-gradient(800px 400px at 0% 20%, rgba(99,102,241,.15), transparent 60%),
      var(--bg);
    padding-bottom:40px;
  }

  /* Header */
  .header-1{
    display:flex;justify-content:space-between;align-items:center;
    padding:20px 40px;
  }
  .logo-section{display:flex;align-items:center;gap:14px}
  .logo-box{
    width:56px;height:56px;border-radius:16px;background:var(--grad);
    display:flex;align-items:center;justify-content:center;box-shadow:var(--shadow);
    overflow:hidden;
  }
  .logo-box img{width:100%;height:100%;object-fit:cover}
  .logo-section h2{font-size:18px;font-weight:800;letter-spacing:1px;line-height:1.2}
  .logo-section h2 span{display:block;font-size:12px;font-weight:400;color:var(--muted);letter-spacing:.3px}
  .profile-section{
    display:flex;align-items:center;gap:12px;padding:8px 16px 8px 8px;border-radius:999px;
    background:var(--panel);border:1px solid var(--border);cursor:pointer;transition:.2s;
  }
  .profile-section:hover{background:var(--panel-2);border-color:var(--border-strong)}
  .profile-section img{width:40px;height:40px;border-radius:50%;object-fit:cover}
  .profile-section h2{font-size:14px;font-weight:600}
  .profile-section .status{font-size:11px;color:var(--green);display:flex;align-items:center;gap:4px}
  .profile-section .status::before{content:"";width:6px;height:6px;background:var(--green);border-radius:50%}

  /* Main grid */
  .main-section{
    display:grid;grid-template-columns:1fr;gap:24px;
    padding:0 40px;max-width:1400px;margin:0 auto;
  }

  /* Hero row: title + languages */
  .hero-card{
   /* background:linear-gradient(180deg,rgba(28,28,61,.6),rgba(22,22,50,.6));*/
    border:1px solid var(--border);border-radius:24px;
    display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:24px;padding:10px;
  }
  .hero-left .chip{
    display:inline-block;padding:6px 14px;border-radius:999px;
    background:var(--grad-soft);border:1px solid rgba(99,102,241,.3);
    color:#a5b4fc;font-size:12px;font-weight:600;margin-bottom:14px;
  }
  .hero-left h1{font-size:32px;font-weight:800;letter-spacing:-.5px}
  .hero-left h1 span{background:var(--grad);-webkit-background-clip:text;background-clip:text;color:transparent}
  .hero-left p{color:var(--muted);margin-top:6px;font-size:14px}

  /* Language picker */
  .lang-sec{display:flex;gap:12px;flex-wrap:wrap}
  .lang-sec .lang{
    width:76px;height:76px;border-radius:16px;background:var(--panel);
    border:1px solid var(--border);display:flex;flex-direction:column;align-items:center;justify-content:center;
    gap:4px;cursor:pointer;transition:.25s;position:relative;
  }
  .lang-sec .lang:hover{transform:translateY(-3px);border-color:rgba(139,92,246,.5)}
  .lang-sec .lang img{width:34px;height:34px;object-fit:contain}
  .lang-sec .lang small{font-size:10px;color:var(--muted);font-weight:500}
  .lang-sec .lang.active{background:var(--grad);border-color:transparent;box-shadow:var(--shadow)}
  .lang-sec .lang.active small{color:#fff}

  /* Editor platform */
  .platform{
    background:linear-gradient(180deg,rgba(28,28,61,.5),rgba(22,22,50,.5));
    border:1px solid var(--border);border-radius:24px;padding:24px;
  }
  .language{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:20px;flex-wrap:wrap}
  .language h2{font-size:20px;font-weight:700;display:flex;align-items:center;gap:12px}
  .language h2 i{
    width:40px;height:40px;border-radius:12px;background:var(--grad-soft);
    display:inline-flex;align-items:center;justify-content:center;color:#a5b4fc;font-size:18px;
  }
  .execute{display:flex;gap:10px;flex-wrap:wrap}
  .execute button{
    padding:10px 18px;border:none;border-radius:12px;font-weight:600;font-size:14px;cursor:pointer;
    display:inline-flex;align-items:center;gap:8px;transition:.2s;color:#fff;font-family:inherit;
  }
  .btn-run{background:linear-gradient(135deg,#22c55e,#16a34a);box-shadow:0 8px 20px -8px rgba(34,197,94,.5)}
  .btn-save{background:var(--grad);box-shadow:var(--shadow)}
  .btn-home{background:var(--panel);border:1px solid var(--border)!important;color:var(--text)}
  .execute button:hover{transform:translateY(-2px);filter:brightness(1.08)}

  /* Editor two-column */
  .editor-grid{display:grid;grid-template-columns:1fr 380px;gap:20px}
  @media(max-width:960px){.editor-grid{grid-template-columns:1fr}}

  .code-window{
    background:#0a0a1e;border:1px solid var(--border);border-radius:16px;overflow:hidden;
  }
  .code-window-bar{
    display:flex;align-items:center;gap:8px;padding:12px 16px;
    background:rgba(255,255,255,.02);border-bottom:1px solid var(--border);
  }
  .code-window-bar .dot{width:12px;height:12px;border-radius:50%}
  .dot.r{background:#ff5f56}.dot.y{background:#ffbd2e}.dot.g{background:#27c93f}
  .code-window-bar .fname{margin-left:12px;font-size:12px;color:var(--muted);font-family:'JetBrains Mono',monospace}

  #editor{
    width:100%;min-height:340px;padding:18px;border:none;outline:none;resize:vertical;
    background:transparent;color:#eef0ff;font-family:'JetBrains Mono',monospace;font-size:14px;line-height:1.7;
  }

  .side-panel{display:flex;flex-direction:column;gap:16px}
  .card{
    background:#0a0a1e;border:1px solid var(--border);border-radius:16px;overflow:hidden;
  }
  .card-head{
    padding:12px 16px;border-bottom:1px solid var(--border);
    display:flex;align-items:center;gap:8px;font-size:13px;font-weight:600;color:var(--muted);
  }
  .card-head i{color:#a5b4fc}
  #userInput{
    width:100%;min-height:120px;padding:14px;border:none;outline:none;resize:vertical;
    background:transparent;color:#eef0ff;font-family:'JetBrains Mono',monospace;font-size:13px;line-height:1.6;
  }
  #output{
    padding:14px;min-height:180px;color:#86efac;font-family:'JetBrains Mono',monospace;font-size:13px;
    white-space:pre-wrap;line-height:1.6;
  }
  #output:empty::before{content:"// Run your code to see output here";color:var(--dim);font-style:italic}

  ::placeholder{color:var(--dim)}
  textarea:focus{outline:none}

  /* Popup */
  .overlay{position:fixed;inset:0;background:rgba(5,5,15,.75);backdrop-filter:blur(8px);display:none;z-index:99}
  .sub-popupp{
    display:none;position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);
    background:var(--panel);border:1px solid var(--border-strong);padding:28px;border-radius:20px;
    box-shadow:var(--shadow);z-index:100;width:min(92vw,400px);
  }
  .sub-popupp h3{margin-bottom:18px;display:flex;align-items:center;gap:10px;font-size:18px}
  .sub-popupp h3 i{
    width:36px;height:36px;border-radius:10px;background:var(--grad-soft);
    display:inline-flex;align-items:center;justify-content:center;color:#a5b4fc;
  }
  .sub-popupp form{display:flex;flex-direction:column;width:100%}
  .sub-popupp input{
    padding:13px 16px;border:1px solid var(--border);border-radius:12px;background:#0a0a1e;
    color:var(--text);font-size:14px;margin-bottom:14px;font-family:inherit;
  }
  .sub-popupp input:focus{outline:none;border-color:var(--indigo);box-shadow:0 0 0 3px rgba(99,102,241,.2)}
  .popup-btns{display:flex;gap:10px}
  .popup-btns button{flex:1;padding:12px;border:none;border-radius:12px;font-weight:600;cursor:pointer;color:#fff;font-family:inherit;font-size:14px}
  .btn-primary{background:var(--grad)}
  .btn-secondary{background:var(--panel-2);border:1px solid var(--border)!important;color:var(--text)}

  /* Toast */
  .toast{
    position:fixed;bottom:24px;right:24px;background:var(--panel);border:1px solid var(--border-strong);
    padding:14px 20px;border-radius:14px;box-shadow:var(--shadow);display:none;align-items:center;gap:10px;z-index:200;
    animation:slide .3s ease;
  }
  .toast.success{border-left:4px solid var(--green)}
  .toast.error{border-left:4px solid #ef4444}
  @keyframes slide{from{transform:translateX(20px);opacity:0}to{transform:translateX(0);opacity:1}}

  @media(max-width:640px){
    .header-1,.main-section{padding-left:20px;padding-right:20px}
    .hero-left h1{font-size:24px}
    .lang-sec .lang{width:66px;height:66px}
  }
</style>
</head>
<body>

<header class="header-1">
  <div class="logo-section">
    <div class="logo-box"><img src="../images/logo.jpeg" alt="Logo"></div>
    <h2>CODE CRYPT<span>Developer's Option</span></h2>
  </div>
  <div class="profile-section" onclick="togglePopup && togglePopup()">
    <img src="../code/<?php echo $profilePic; ?>" alt="">
    <div>
      <h2><?php echo $firstname; ?></h2>
      <div class="status">Online</div>
    </div>
  </div>
</header>

<main class="main-section">

  <!-- Hero + language picker -->
  <section class="hero-card">
    <div class="hero-left">
      <span class="chip">Welcome back</span>
      <h1>Hey, <span><?php echo $firstname; ?></span> 👋</h1>
      <p>Write, run and save code across languages — right in your browser.</p>
    </div>
    <div class="lang-sec">
      <div class="lang active" onclick="python()"><img src="../images/python.png"><small>Python</small></div>
      <div class="lang" onclick="java()"><img src="../images/java.png"><small>Java</small></div>
      <div class="lang" onclick="php()"><img src="../images/php.png"><small>PHP</small></div>
      <div class="lang" onclick="html()"><img src="../images/html.png"><small>HTML</small></div>
      <div class="lang" onclick="js()"><img src="../images/js.png"><small>JS</small></div>
      <div class="lang" onclick="c()"><img src="../images/c.png"><small>C</small></div>
      <div class="lang" onclick="cpp()"><img src="../images/cpp.png"><small>C++</small></div>
    </div>
  </section>

  <!-- Editor -->
  <section class="platform">
    <div class="language">
      <h2><i class="fa-brands fa-python"></i> Python Programming</h2>
      <div class="execute">
        <button class="btn-run" onclick="executeCode()"><i class="fa-solid fa-play"></i> Run</button>
        <button class="btn-save" onclick="openSavePopup()"><i class="fa-solid fa-floppy-disk"></i> Save</button>
        <button class="btn-home" onclick="goHome()"><i class="fa-solid fa-house"></i> Home</button>
      </div>
    </div>

    <div class="editor-grid">
      <div class="code-window">
        <div class="code-window-bar">
          <span class="dot r"></span><span class="dot y"></span><span class="dot g"></span>
          <span class="fname">main.py</span>
        </div>
        <textarea id="editor" spellcheck="false">print("Hello, World!")</textarea>
      </div>

      <div class="side-panel">
        <div class="card">
          <div class="card-head"><i class="fa-solid fa-keyboard"></i> Standard Input</div>
          <textarea id="userInput" placeholder="One value per line for input()..."></textarea>
        </div>
        <div class="card">
          <div class="card-head"><i class="fa-solid fa-terminal"></i> Output</div>
          <pre id="output"></pre>
        </div>
      </div>
    </div>
  </section>
</main>

<!-- Save popup -->
<div class="overlay" id="overlay" onclick="closeSavePopup()"></div>
<div class="sub-popupp" id="savePopup">
  <h3><i class="fa-solid fa-floppy-disk"></i> Save your file</h3>
  <form onsubmit="saveFile(event)">
    <input type="text" id="filename" placeholder="e.g. hello.py" required>
    <div class="popup-btns">
      <button type="button" class="btn-secondary" onclick="closeSavePopup()">Cancel</button>
      <button type="submit" class="btn-primary">Save</button>
    </div>
  </form>
</div>

<div class="toast" id="toast"><i class="fa-solid fa-circle-check"></i> <span id="toastMsg"></span></div>

<script>
function showToast(msg, type){
  const t=document.getElementById('toast');
  t.className='toast '+(type||'success');
  document.getElementById('toastMsg').innerText=msg;
  t.style.display='flex';
  setTimeout(()=>t.style.display='none',2800);
}

function executeCode(){
  const code=document.getElementById("editor").value;
  const userInput=document.getElementById("userInput").value;
  const out=document.getElementById("output");
  out.style.color="#a5b4fc";
  out.innerText="Running...";
  fetch("execute.php",{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({code:code,stdin:userInput})
  })
  .then(async (r)=>{
    const text = await r.text();
    console.log("Server Response:", text);
    return JSON.parse(text);
})
.then(data=>{
    out.style.color="#86efac";

    if(data.output){
        out.innerText = data.output;
    }else if(data.error){
        out.innerText = data.error;
    }else{
        out.innerText = JSON.stringify(data,null,2);
    }
})
.catch(err=>{
    out.style.color="#fca5a5";
    out.innerText="Error: "+err;
});
}

function openSavePopup(){
  document.getElementById("savePopup").style.display="block";
  document.getElementById("overlay").style.display="block";
}
function closeSavePopup(){
  document.getElementById("savePopup").style.display="none";
  document.getElementById("overlay").style.display="none";
}

function saveFile(event){
  event.preventDefault();
  const code=document.getElementById("editor").value;
  const filename=document.getElementById("filename").value;
  fetch("save.php",{
    method:"POST",
    headers:{"Content-Type":"application/x-www-form-urlencoded"},
    body:"filename="+encodeURIComponent(filename)+"&code="+encodeURIComponent(code)
  })
  .then(r=>r.text())
  .then(data=>{showToast(data,'success');closeSavePopup();})
  .catch(err=>showToast("Error: "+err,'error'));
}

function python(){window.location.href='../flask_project/index.php';}
function java(){window.location.href='../java/java.php';}
function php(){window.location.href='../php/index.php';}
function js(){window.location.href='../jsonlinecompiler/index.php';}
function html(){window.location.href='../web/index.php';}
function c(){window.location.href='../c/index.php';}
function cpp(){window.location.href='../cpponlinecompiler/index.php';}
function goHome(){window.location.href="../code/home.php";}
</script>
</body>
</html>
